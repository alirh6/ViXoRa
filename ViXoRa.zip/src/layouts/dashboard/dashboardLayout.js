

export function createDashboardLayout (ctx) {
  let outlet = null

  function render () {
    return /*html*/`
      <div class="dashboardLayoutRoot">
        <header class="DLHeader">
          <section class="DLHeaderL-userInfo">
            <div class="DLHeaderL-userImgWrapper">
              ${ctx.user.avatar
                  ? `
                    <img class="DLHeaderL-userImg" src="${ctx.user.avatar}" alt="">
                  `
                  : `
                    <div class="DLHeaderL-guestImg"></div>
                  `
              }
            </div>
            <div class="DLHeaderL-usernameWrapper">
              ${ctx.user.name
                  ? `
                    <span class="DLHeaderL-username">${ctx.user.name}</span>
                  `
                  : `
                    <span class="DLHeader-loginButNoName"></span>
                  `
              }
            </div>
            <div class="DLHeaderL-usernameWrapper">
              ${ctx.user.username
                  ? `
                    <span class="DLHeaderL-username">${ctx.user.username}</span>
                  `
                  : `
                    <span class="DLHeader-loginButNoName"></span>
                  `
              }
            </div>
            <div class="DLHeaderL-usernameWrapper">
              ${ctx.user.email
                  ? `
                    <span class="DLHeaderL-username">${ctx.user.email}</span>
                  `
                  : `
                    <span class="DLHeader-loginButNoName"></span>
                  `
              }
            </div>
            <div class="DLHeaderL-usernameWrapper">
              ${ctx.user.phoneNumber
                  ? `
                    <span class="DLHeaderL-username">${ctx.user.phoneNumber}</span>
                  `
                  : `
                    <span class="DLHeader-loginButNoName"></span>
                  `
              }
            </div>

            <div class="DLHeaderL-usernameWrapper">
              ${ctx.user.profileIsComplete
                  ? `
                    <span class="DLHeader-loginButNoName"></span>
                  `
                  : `
                    <div class="DLHeaderL-profileCompletePage">takmile profile</div>
                  `
              }
            </div>

          </section>

          <section class="DLHeader-middle"></section>

          <section class="DLHeader-right"></section>
        </header>


        <div class="outlet dashboardMain"></div>
      </div>

      
    `
  }


  function afterRender () {
    outlet = document.querySelector(".outlet")
  }

  function getOutlet () {
    return outlet
  }


  function destroy () {

  }

  return {
    render,
    afterRender,
    getOutlet,
    destroy
  }
}