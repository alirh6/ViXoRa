/**
 * =========================================================
 * ViXoRa · Note Workspace Page (Functional Factory · Production)
 * src/pages/tools/note/NotePage.js
 * ---------------------------------------------------------
 * قرارداد با روتر ViXoRa:
 *   createNotePage(ctx) => { render(), afterRender(), destroy() }
 *
 * داده‌ها:
 *   نوت‌ها از طریق tools-service در user.tools.notes ذخیره و
 *   با json-server + appStore + session-storage سینک می‌شوند.
 *   فقط «تنظیمات ظاهری» صفحه در localStorage نگه‌داری می‌شود.
 * =========================================================
 */

import {
  getToolData,
  createToolItem,
  updateToolItem,
  deleteToolItem,
} from '../../../core/actions/tools-service.js';

import { appStore, setTheme } from '../../../core/state/app-state.js';
import { selectTheme } from '../../../core/state/selectors.js';

/* =========================================================
 * ثابت‌ها
 * ========================================================= */

const TOOL_NAME = 'notes';
const PAGE_ID = 'note-page';
const PREFS_KEY = 'vixora:note-page:prefs:v2';
const SEARCH_DEBOUNCE_MS = 200;
const TOAST_TTL_MS = 4200;

const COLOR_KEYS = ['violet', 'blue', 'emerald', 'amber', 'rose', 'slate'];
const PRIORITY_KEYS = ['low', 'medium', 'high', 'urgent'];
const STATUS_KEYS = ['todo', 'doing', 'done', 'archived'];

const PRIORITY_RANK = { low: 1, medium: 2, high: 3, urgent: 4 };

const STATUS_LABELS = {
  todo: 'در انتظار',
  doing: 'در حال انجام',
  done: 'انجام‌شده',
  archived: 'بایگانی',
};

const PRIORITY_LABELS = {
  low: 'کم',
  medium: 'متوسط',
  high: 'زیاد',
  urgent: 'فوری',
};

const COLOR_LABELS = {
  violet: 'بنفش',
  blue: 'آبی',
  emerald: 'سبز',
  amber: 'کهربایی',
  rose: 'رز',
  slate: 'خاکستری',
};

const VIEW_OPTIONS = [
  ['grid', 'شبکه‌ای'],
  ['list', 'لیستی'],
  ['board', 'برد'],
  ['timeline', 'خط‌زمان'],
  ['calendar', 'تقویم'],
  ['masonry', 'موزاییکی'],
];

const SORT_OPTIONS = [
  ['smart', 'مرتب‌سازی هوشمند'],
  ['updated', 'آخرین بروزرسانی'],
  ['created', 'آخرین ایجاد'],
  ['alphabetical', 'الفبایی'],
  ['priority', 'بر اساس اولویت'],
  ['due', 'نزدیک‌ترین موعد'],
  ['pinned', 'سنجاق‌شده‌ها اول'],
  ['favorite', 'علاقه‌مندی‌ها اول'],
  ['neglected', 'کهنه‌ترین‌ها اول'],
  ['momentum', 'بیشترین پویایی'],
  ['random', 'تصادفی'],
];

const GROUP_OPTIONS = [
  ['none', 'بدون گروه‌بندی'],
  ['status', 'گروه‌بندی: وضعیت'],
  ['priority', 'گروه‌بندی: اولویت'],
  ['color', 'گروه‌بندی: رنگ'],
  ['category', 'گروه‌بندی: دسته‌بندی'],
];

const SEARCH_SCOPE_OPTIONS = [
  ['all', 'همه جا'],
  ['title', 'عنوان'],
  ['content', 'محتوا'],
  ['tags', 'تگ‌ها'],
  ['category', 'دسته‌بندی'],
  ['color', 'رنگ'],
  ['date', 'تاریخ'],
];

const VIEW_LABELS = Object.fromEntries(VIEW_OPTIONS);
const SORT_LABELS = Object.fromEntries(SORT_OPTIONS);

/* =========================================================
 * آیکون‌های SVG (بدون ایموجی — سبک Lucide)
 * ========================================================= */

const ICON_PATHS = {
  note: '<path d="M15.5 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8.5Z"/><path d="M15 3v6h6"/><path d="M9 13h6"/><path d="M9 17h4"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.9 4.9 1.4 1.4"/><path d="m17.7 17.7 1.4 1.4"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.3 17.7-1.4 1.4"/><path d="m19.1 4.9-1.4 1.4"/>',
  moon: '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79Z"/>',
  density: '<path d="M3 5h18"/><path d="M3 10h18"/><path d="M3 15h18"/><path d="M3 20h18"/>',
  chart: '<path d="M3 3v16a2 2 0 0 0 2 2h16"/><path d="M8 17v-6"/><path d="M13 17V7"/><path d="M18 17v-3"/>',
  layers: '<path d="m12 2 10 5-10 5L2 7Z"/><path d="m2 17 10 5 10-5"/><path d="m2 12 10 5 10-5"/>',
  sliders: '<path d="M4 21v-7"/><path d="M4 10V3"/><path d="M12 21v-9"/><path d="M12 8V3"/><path d="M20 21v-5"/><path d="M20 12V3"/><path d="M2 14h4"/><path d="M10 8h4"/><path d="M18 16h4"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/>',
  upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m17 8-5-5-5 5"/><path d="M12 3v12"/>',
  refresh: '<path d="M3 12a9 9 0 0 1 15.5-6.4L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15.5 6.4L3 16"/><path d="M3 21v-5h5"/>',
  undo: '<path d="M3 7v6h6"/><path d="M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13"/>',
  pin: '<path d="M12 17v5"/><path d="M9 10.76a2 2 0 0 1-1.11 1.79L3 14v1a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1v-1l-4.89-1.45A2 2 0 0 1 15 10.76V7h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1Z"/>',
  star: '<path d="m12 2 3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01Z"/>',
  pencil: '<path d="M17 3a2.85 2.85 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/>',
  trash: '<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M10 11v6"/><path d="M14 11v6"/>',
  copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
  plus: '<path d="M12 5v14"/><path d="M5 12h14"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>',
  filter: '<path d="M22 3H2l8 9.46V19l4 2v-8.54Z"/>',
  dots: '<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/>',
  list: '<path d="M8 6h13"/><path d="M8 12h13"/><path d="M8 18h13"/><path d="M3 6h.01"/><path d="M3 12h.01"/><path d="M3 18h.01"/>',
  board: '<rect x="3" y="3" width="5" height="18" rx="1"/><rect x="10" y="3" width="5" height="12" rx="1"/><rect x="17" y="3" width="4" height="8" rx="1"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4"/><path d="M8 2v4"/><path d="M3 10h18"/>',
  masonry: '<rect x="3" y="3" width="8" height="10" rx="1"/><rect x="3" y="15" width="8" height="6" rx="1"/><rect x="13" y="3" width="8" height="6" rx="1"/><rect x="13" y="11" width="8" height="10" rx="1"/>',
  archive: '<rect x="3" y="4" width="18" height="5" rx="1"/><path d="M5 9v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V9"/><path d="M10 13h4"/>',
  inbox: '<path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11Z"/>',
  alert: '<path d="m10.29 3.86-8.47 14.14a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0Z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
  checklist: '<path d="m3 17 2 2 4-4"/><path d="m3 7 2 2 4-4"/><path d="M13 6h8"/><path d="M13 12h8"/><path d="M13 18h8"/>',
  zap: '<path d="M13 2 3 14h7l-1 8 11-13h-7l1-7Z"/>',
};

const VIEW_ICONS = {
  grid: 'grid',
  list: 'list',
  board: 'board',
  timeline: 'clock',
  calendar: 'calendar',
  masonry: 'masonry',
};

/* =========================================================
 * فکتوری صفحه
 * ========================================================= */

export function createNotePage(ctx = {}) {
  /* ---------- state داخلی ---------- */

  let root = null;
  let isDestroyed = false;
  let hasLoaded = false;
  let isLoading = true;
  let loadError = null;

  let searchDebounceTimer = null;
  let unsubscribeStore = null;

  let toastSeq = 0;
  let toasts = [];
  const toastTimers = new Map();

  let confirmState = null;
  let confirmResolver = null;

  /* صف سریالی برای mutationها تا روی سند کاربر Race پیش نیاید */
  let opChain = Promise.resolve();

  let state = createInitialState();

  /* =========================================================
   * ساخت و مدیریت state
   * ========================================================= */

  function createEmptyDraft() {
    return {
      title: '',
      content: '',
      category: '',
      priority: 'medium',
      color: 'blue',
      status: 'todo',
      dueAt: '',
      tags: '',
      checklist: [],
    };
  }

  function getDefaultUi() {
    return {
      query: typeof ctx?.query?.q === 'string' ? ctx.query.q : '',
      searchScope: 'all',
      activeView: 'grid',
      activeSort: 'smart',
      groupBy: 'none',

      selectedIds: [],
      selectionMode: false,

      activeBucket: 'all',
      activePriorityFilter: 'all',
      activeColorFilter: 'all',

      showFavoritesOnly: false,
      showPinnedOnly: false,
      showArchivedOnly: false,
      showTrashOnly: false,
      showChecklistOnly: false,
      showOverdueOnly: false,
      showTodayOnly: false,

      isMoreMenuOpen: false,
      isFilterPanelOpen: false,
      isBulkBarOpen: false,
      isAnalyticsOpen: false,
      isTemplatePanelOpen: false,
      isHeaderCustomizeOpen: false,
      isQuickAddOpen: false,

      theme: selectTheme(safeStoreState()) || 'light',
      density: 'comfortable',

      editingNoteId: null,
      draftNote: createEmptyDraft(),
    };
  }

  function getDefaultHeaderConfig() {
    return {
      pinned: ['toggle-theme', 'toggle-density', 'toggle-analytics'],
      menu: [
        'toggle-template-panel',
        'toggle-header-customize',
        'export-notes',
        'import-notes',
        'clear-filters',
      ],
    };
  }

  function createInitialState() {
    const now = new Date().toISOString();

    const defaults = {
      notes: [],
      headerConfig: getDefaultHeaderConfig(),
      ui: getDefaultUi(),
      meta: { createdAt: now, updatedAt: now },
    };

    const saved = readPrefs();
    if (!saved) return defaults;

    return {
      ...defaults,
      headerConfig: {
        pinned: Array.isArray(saved.headerConfig?.pinned)
          ? saved.headerConfig.pinned
          : defaults.headerConfig.pinned,
        menu: Array.isArray(saved.headerConfig?.menu)
          ? saved.headerConfig.menu
          : defaults.headerConfig.menu,
      },
      ui: {
        ...defaults.ui,
        ...(saved.ui || {}),
        // ورودی‌های فرّار را به حالت امن برمی‌گردانیم
        isMoreMenuOpen: false,
        isQuickAddOpen: false,
        editingNoteId: null,
        draftNote: {
          ...createEmptyDraft(),
          ...(saved.ui?.draftNote || {}),
          checklist: Array.isArray(saved.ui?.draftNote?.checklist)
            ? saved.ui.draftNote.checklist
            : [],
        },
        selectedIds: [],
        selectionMode: false,
        isBulkBarOpen: false,
        // تم همیشه از استور گلوبال خوانده می‌شود
        theme: selectTheme(safeStoreState()) || 'light',
      },
      meta: { ...defaults.meta, ...(saved.meta || {}) },
    };
  }

  function safeStoreState() {
    try {
      return appStore?.getState?.() ?? {};
    } catch {
      return {};
    }
  }

  function readPrefs() {
    try {
      const raw = window.localStorage.getItem(PREFS_KEY);
      if (!raw) return null;
      return JSON.parse(raw);
    } catch (err) {
      console.warn('[NotePage] Failed to read prefs:', err);
      return null;
    }
  }

  function persistPrefs() {
    try {
      window.localStorage.setItem(
        PREFS_KEY,
        JSON.stringify({
          ui: state.ui,
          headerConfig: state.headerConfig,
          meta: state.meta,
        })
      );
    } catch (err) {
      console.warn('[NotePage] Failed to persist prefs:', err);
    }
  }

  function setState(patch = {}, options = {}) {
    const { render = true, persist = true, preserveFocus = true } = options;

    const prev = state;

    state = {
      ...prev,
      ...patch,
      ui: {
        ...prev.ui,
        ...(patch.ui || {}),
        draftNote: {
          ...prev.ui.draftNote,
          ...(patch.ui?.draftNote || {}),
        },
      },
      headerConfig: {
        ...prev.headerConfig,
        ...(patch.headerConfig || {}),
      },
      meta: {
        ...prev.meta,
        ...(patch.meta || {}),
        updatedAt: new Date().toISOString(),
      },
      notes: patch.notes !== undefined ? patch.notes : prev.notes,
    };

    if (persist) persistPrefs();
    if (render) rerender({ preserveFocus });

    return state;
  }

  function updateUI(updater, options) {
    const nextUi =
      typeof updater === 'function' ? updater({ ...state.ui }) : updater;
    setState({ ui: nextUi }, options);
  }

  /* =========================================================
   * صف عملیات async (ضد Race روی سند کاربر)
   * ========================================================= */

  function enqueueOp(fn) {
    const task = opChain.then(() => fn());
    opChain = task.catch(() => {
      /* خطاها در محل فراخوانی مدیریت می‌شوند */
    });
    return task;
  }

  function isCtxAborted() {
    return isDestroyed || Boolean(ctx?.signal?.aborted);
  }

  /* =========================================================
   * بارگذاری داده از tools-service
   * ========================================================= */

  async function loadNotes() {
    isLoading = true;
    loadError = null;
    rerender({ preserveFocus: false });

    try {
      const list = await getToolData(TOOL_NAME);
      if (isCtxAborted()) return;

      hasLoaded = true;
      isLoading = false;
      loadError = null;

      setState(
        {
          notes: (Array.isArray(list) ? list : []).map(normalizeNote),
        },
        { preserveFocus: false }
      );
    } catch (err) {
      if (isCtxAborted()) return;

      console.error('[NotePage] Failed to load notes:', err);
      hasLoaded = true;
      isLoading = false;
      loadError =
        'بارگذاری یادداشت‌ها ناموفق بود. اتصال به سرور را بررسی کنید.';
      rerender({ preserveFocus: false });
    }
  }

  function normalizeNote(note) {
    const safe = note && typeof note === 'object' ? note : {};
    return {
      ...safe,
      id: String(safe.id ?? ''),
      title: typeof safe.title === 'string' ? safe.title : '',
      content: typeof safe.content === 'string' ? safe.content : '',
      category: typeof safe.category === 'string' ? safe.category : '',
      priority: PRIORITY_KEYS.includes(safe.priority) ? safe.priority : 'medium',
      color: COLOR_KEYS.includes(safe.color) ? safe.color : 'slate',
      status: STATUS_KEYS.includes(safe.status) ? safe.status : 'todo',
      dueAt: typeof safe.dueAt === 'string' ? safe.dueAt : '',
      tags: Array.isArray(safe.tags) ? safe.tags.map(String) : [],
      checklist: Array.isArray(safe.checklist)
        ? safe.checklist.map((item) => ({
            id: String(item?.id ?? createLocalId('check')),
            text: String(item?.text ?? ''),
            done: Boolean(item?.done),
          }))
        : [],
      pinned: Boolean(safe.pinned),
      favorite: Boolean(safe.favorite),
      archived: Boolean(safe.archived),
      trashed: Boolean(safe.trashed),
    };
  }

  function createLocalId(prefix) {
    if (typeof crypto !== 'undefined' && crypto.randomUUID) {
      return `${prefix}-${crypto.randomUUID()}`;
    }
    return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
  }

  /* =========================================================
   * عملیات CRUD (همگام با tools-service)
   * ========================================================= */

  function findNoteById(noteId) {
    return state.notes.find((n) => String(n.id) === String(noteId)) || null;
  }

  async function commitCreate(payload) {
    try {
      const created = await enqueueOp(() => createToolItem(TOOL_NAME, payload));
      if (isCtxAborted()) return null;

      setState(
        { notes: [normalizeNote(created), ...state.notes] },
        { preserveFocus: false }
      );
      return created;
    } catch (err) {
      console.error('[NotePage] create failed:', err);
      showToast('ایجاد یادداشت انجام نشد. دوباره تلاش کنید.', 'error');
      return null;
    }
  }

  async function commitUpdate(noteId, fields) {
    try {
      const updated = await enqueueOp(() =>
        updateToolItem(TOOL_NAME, noteId, fields)
      );
      if (isCtxAborted()) return null;

      const normalized = normalizeNote(updated);
      setState(
        {
          notes: state.notes.map((n) =>
            String(n.id) === String(noteId) ? normalized : n
          ),
        },
        { preserveFocus: false }
      );
      return updated;
    } catch (err) {
      console.error('[NotePage] update failed:', err);
      showToast('بروزرسانی انجام نشد. دوباره تلاش کنید.', 'error');
      return null;
    }
  }

  async function commitDelete(noteId) {
    try {
      await enqueueOp(() => deleteToolItem(TOOL_NAME, noteId));
      if (isCtxAborted()) return false;

      setState(
        {
          notes: state.notes.filter((n) => String(n.id) !== String(noteId)),
          ui: {
            ...state.ui,
            selectedIds: state.ui.selectedIds.filter(
              (id) => String(id) !== String(noteId)
            ),
            editingNoteId:
              state.ui.editingNoteId === noteId
                ? null
                : state.ui.editingNoteId,
          },
        },
        { preserveFocus: false }
      );
      return true;
    } catch (err) {
      console.error('[NotePage] delete failed:', err);
      showToast('حذف انجام نشد. دوباره تلاش کنید.', 'error');
      return false;
    }
  }

  /* =========================================================
   * اکشن‌های نوت
   * ========================================================= */

  async function saveDraftNote() {
    const draft = state.ui.draftNote || createEmptyDraft();
    const title = String(draft.title || '').trim();
    const content = String(draft.content || '').trim();

    if (!title && !content) {
      showToast('حداقل عنوان یا محتوا را وارد کنید.', 'error');
      return;
    }

    const tags = String(draft.tags || '')
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);

    const checklist = Array.isArray(draft.checklist)
      ? draft.checklist
          .map((item) => ({
            id: String(item?.id ?? createLocalId('check')),
            text: String(item?.text ?? '').trim(),
            done: Boolean(item?.done),
          }))
          .filter((item) => item.text)
      : [];

    const baseFields = {
      title: title || 'بدون عنوان',
      content,
      category: String(draft.category || '').trim(),
      priority: PRIORITY_KEYS.includes(draft.priority)
        ? draft.priority
        : 'medium',
      color: COLOR_KEYS.includes(draft.color) ? draft.color : 'blue',
      status: STATUS_KEYS.includes(draft.status) ? draft.status : 'todo',
      dueAt: draft.dueAt || '',
      tags,
      checklist,
    };

    const editingId = state.ui.editingNoteId;
    let ok = false;

    if (editingId) {
      ok = Boolean(await commitUpdate(editingId, baseFields));
      if (ok) showToast('تغییرات ذخیره شد.', 'success');
    } else {
      ok = Boolean(
        await commitCreate({
          ...baseFields,
          pinned: false,
          favorite: false,
          archived: false,
          trashed: false,
        })
      );
      if (ok) showToast('یادداشت جدید ایجاد شد.', 'success');
    }

    if (!ok || isCtxAborted()) return;

    updateUI((ui) => ({
      ...ui,
      isQuickAddOpen: false,
      editingNoteId: null,
      draftNote: createEmptyDraft(),
    }));
  }

  async function trashNote(noteId) {
    const note = findNoteById(noteId);
    if (!note) return;

    if (note.trashed) {
      // حذف دائمی
      const accepted = await askConfirm({
        title: 'حذف دائمی یادداشت',
        message: `«${note.title || 'بدون عنوان'}» برای همیشه حذف می‌شود و قابل بازگشت نیست.`,
        confirmLabel: 'حذف دائمی',
        danger: true,
      });
      if (!accepted) return;

      const ok = await commitDelete(noteId);
      if (ok) showToast('یادداشت برای همیشه حذف شد.', 'info');
      return;
    }

    // انتقال به سطل زباله + امکان Undo
    const ok = await commitUpdate(noteId, { trashed: true, archived: false });
    if (!ok) return;

    showToast('به سطل زباله منتقل شد.', 'info', {
      label: 'بازگردانی',
      run: () => {
        void commitUpdate(noteId, { trashed: false });
      },
    });
  }

  async function restoreNote(noteId) {
    const ok = await commitUpdate(noteId, { trashed: false });
    if (ok) showToast('یادداشت بازیابی شد.', 'success');
  }

  async function emptyTrash() {
    const trashedIds = state.notes
      .filter((n) => n.trashed)
      .map((n) => String(n.id));

    if (!trashedIds.length) return;

    const accepted = await askConfirm({
      title: 'خالی کردن سطل زباله',
      message: `${faNumber(trashedIds.length)} یادداشت برای همیشه حذف می‌شوند.`,
      confirmLabel: 'خالی کردن',
      danger: true,
    });
    if (!accepted) return;

    try {
      await enqueueOp(async () => {
        for (const id of trashedIds) {
          await deleteToolItem(TOOL_NAME, id);
        }
      });
      if (isCtxAborted()) return;

      setState(
        { notes: state.notes.filter((n) => !n.trashed) },
        { preserveFocus: false }
      );
      showToast('سطل زباله خالی شد.', 'success');
    } catch (err) {
      console.error('[NotePage] empty trash failed:', err);
      showToast('خالی کردن سطل زباله کامل نشد.', 'error');
    }
  }

  function togglePin(noteId) {
    const note = findNoteById(noteId);
    if (!note) return;
    void commitUpdate(noteId, { pinned: !note.pinned });
  }

  function toggleFavorite(noteId) {
    const note = findNoteById(noteId);
    if (!note) return;
    void commitUpdate(noteId, { favorite: !note.favorite });
  }

  async function duplicateNote(noteId) {
    const note = findNoteById(noteId);
    if (!note) return;

    const {
      id: _id,
      createdAt: _c,
      updatedAt: _u,
      updated: _x,
      ...rest
    } = note;

    const created = await commitCreate({
      ...rest,
      title: `${note.title || 'بدون عنوان'} (کپی)`,
      pinned: false,
      trashed: false,
    });

    if (created) showToast('کپی یادداشت ایجاد شد.', 'success');
  }

  async function toggleChecklistItem(noteId, checkId) {
    const note = findNoteById(noteId);
    if (!note) return;

    const checklist = note.checklist.map((item) =>
      String(item.id) === String(checkId)
        ? { ...item, done: !item.done }
        : item
    );

    await commitUpdate(noteId, { checklist });
  }

  function toggleNoteSelection(noteId) {
    const selected = new Set(state.ui.selectedIds.map(String));
    const key = String(noteId);

    if (selected.has(key)) selected.delete(key);
    else selected.add(key);

    const selectedIds = [...selected];

    updateUI((ui) => ({
      ...ui,
      selectedIds,
      isBulkBarOpen: selectedIds.length > 0,
    }));
  }

  function selectAllVisible() {
    const ids = getVisibleNotes().map((n) => String(n.id));
    updateUI((ui) => ({
      ...ui,
      selectedIds: ids,
      isBulkBarOpen: ids.length > 0,
    }));
  }

  async function bulkUpdateSelected(updaterFactory, { clearSelection = true } = {}) {
    const ids = state.ui.selectedIds.map(String);
    if (!ids.length) return;

    try {
      await enqueueOp(async () => {
        for (const id of ids) {
          const note = findNoteById(id);
          if (!note) continue;
          await updateToolItem(TOOL_NAME, id, updaterFactory(note));
        }
      });
      if (isCtxAborted()) return;

      // sync مجدد از سرور برای اطمینان از سازگاری کامل
      const list = await getToolData(TOOL_NAME);
      if (isCtxAborted()) return;

      setState(
        {
          notes: (Array.isArray(list) ? list : []).map(normalizeNote),
          ui: clearSelection
            ? {
                ...state.ui,
                selectedIds: [],
                isBulkBarOpen: false,
                selectionMode: false,
              }
            : state.ui,
        },
        { preserveFocus: false }
      );

      showToast('عملیات گروهی انجام شد.', 'success');
    } catch (err) {
      console.error('[NotePage] bulk update failed:', err);
      showToast('عملیات گروهی کامل نشد.', 'error');
    }
  }

  function createNoteFromTemplate(type) {
    const templates = {
      daily: {
        title: 'مرور روزانه',
        content:
          '- ۳ اولویت برتر امروز\n- چه چیزهایی خوب پیش رفت؟\n- چه چیزی نیاز به توجه دارد؟',
        category: 'شخصی',
        priority: 'medium',
        color: 'blue',
        status: 'todo',
        dueAt: '',
        tags: 'روزانه, مرور',
        checklist: [
          { id: createLocalId('check'), text: 'ثبت ۳ اولویت برتر', done: false },
          { id: createLocalId('check'), text: 'مرور اتفاقات روز', done: false },
          { id: createLocalId('check'), text: 'برنامه‌ریزی فردا', done: false },
        ],
      },
      project: {
        title: 'برنامه‌ریزی پروژه',
        content: '- دامنه کار\n- نقاط عطف\n- ریسک‌ها\n- وابستگی‌ها',
        category: 'کاری',
        priority: 'high',
        color: 'violet',
        status: 'doing',
        dueAt: '',
        tags: 'پروژه, برنامه‌ریزی',
        checklist: [
          { id: createLocalId('check'), text: 'تعریف دامنه', done: false },
          { id: createLocalId('check'), text: 'تعیین نقاط عطف', done: false },
          { id: createLocalId('check'), text: 'شناسایی ریسک‌ها', done: false },
        ],
      },
      brainstorm: {
        title: 'طوفان فکری',
        content: '- ایده ۱\n- ایده ۲\n- ایده ۳',
        category: 'ایده‌ها',
        priority: 'low',
        color: 'emerald',
        status: 'todo',
        dueAt: '',
        tags: 'ایده',
        checklist: [],
      },
      meeting: {
        title: 'صورت‌جلسه',
        content:
          '- دستور جلسه:\n- تصمیمات:\n- اقدامات بعدی (مسئول + موعد):',
        category: 'جلسات',
        priority: 'medium',
        color: 'amber',
        status: 'todo',
        dueAt: '',
        tags: 'جلسه',
        checklist: [
          { id: createLocalId('check'), text: 'ارسال صورت‌جلسه برای تیم', done: false },
        ],
      },
    };

    const draft = templates[type] || templates.brainstorm;

    updateUI((ui) => ({
      ...ui,
      isTemplatePanelOpen: false,
      isQuickAddOpen: true,
      editingNoteId: null,
      draftNote: { ...createEmptyDraft(), ...structuredClone(draft) },
      isMoreMenuOpen: false,
    }));
  }

  /* ---------- Export / Import ---------- */

  function exportNotes() {
    try {
      const payload = JSON.stringify(state.notes, null, 2);
      const blob = new Blob([payload], { type: 'application/json' });
      const url = URL.createObjectURL(blob);

      const a = document.createElement('a');
      a.href = url;
      a.download = `vixora-notes-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();

      URL.revokeObjectURL(url);
      showToast('فایل خروجی دانلود شد.', 'success');
    } catch (err) {
      console.error('[NotePage] export failed:', err);
      showToast('ساخت فایل خروجی ناموفق بود.', 'error');
    }
  }

  function importNotes() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'application/json,.json';

    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return;

      let parsed;
      try {
        parsed = JSON.parse(await file.text());
      } catch {
        showToast('فایل JSON معتبر نیست.', 'error');
        return;
      }

      if (!Array.isArray(parsed) || !parsed.length) {
        showToast('ساختار فایل باید آرایه‌ای از یادداشت‌ها باشد.', 'error');
        return;
      }

      const items = parsed.slice(0, 300).map((raw) => {
        const n = normalizeNote(raw);
        return {
          title: n.title || 'بدون عنوان',
          content: n.content,
          category: n.category,
          priority: n.priority,
          color: n.color,
          status: n.status,
          dueAt: n.dueAt,
          tags: n.tags,
          checklist: n.checklist,
          pinned: n.pinned,
          favorite: n.favorite,
          archived: n.archived,
          trashed: n.trashed,
        };
      });

      showToast(`در حال ورود ${faNumber(items.length)} یادداشت...`, 'info');

      try {
        const createdList = await enqueueOp(async () => {
          const acc = [];
          for (const payload of items) {
            acc.push(await createToolItem(TOOL_NAME, payload));
          }
          return acc;
        });

        if (isCtxAborted()) return;

        setState(
          {
            notes: [
              ...createdList.map(normalizeNote),
              ...state.notes,
            ],
          },
          { preserveFocus: false }
        );
        showToast('ورود یادداشت‌ها با موفقیت انجام شد.', 'success');
      } catch (err) {
        console.error('[NotePage] import failed:', err);
        showToast('ورود فایل کامل نشد.', 'error');
      }
    };

    input.click();
  }

  /* ---------- Header actions ---------- */

  function getHeaderActionMeta(actionId) {
    const actions = {
      'toggle-theme': {
        label: 'تم',
        title: 'تغییر تم روشن/تیره',
        icon: state.ui.theme === 'dark' ? 'sun' : 'moon',
      },
      'toggle-density': { label: 'تراکم', title: 'تراکم فشرده/راحت', icon: 'density' },
      'toggle-analytics': { label: 'تحلیل‌ها', title: 'باز/بسته کردن پنل تحلیل', icon: 'chart' },
      'toggle-template-panel': { label: 'قالب‌ها', title: 'پنل قالب‌های آماده', icon: 'layers' },
      'toggle-header-customize': {
        label: 'شخصی‌سازی',
        title: 'شخصی‌سازی اکشن‌های هدر',
        icon: 'sliders',
      },
      'export-notes': { label: 'خروجی', title: 'دریافت خروجی JSON', icon: 'download' },
      'import-notes': { label: 'ورودی', title: 'ورود یادداشت از فایل', icon: 'upload' },
      'clear-filters': { label: 'ریست', title: 'پاک‌سازی همه فیلترها', icon: 'refresh' },
    };
    return actions[actionId] || null;
  }

  function handleHeaderAction(actionId) {
    switch (actionId) {
      case 'toggle-theme': {
        const next = state.ui.theme === 'dark' ? 'light' : 'dark';
        try {
          setTheme(next); // تم گلوبال اپ — سابسکریپشن صفحه را sync می‌کند
        } catch (err) {
          console.warn('[NotePage] setTheme failed:', err);
        }
        break;
      }
      case 'toggle-density':
        updateUI((ui) => ({
          ...ui,
          density: ui.density === 'comfortable' ? 'compact' : 'comfortable',
        }));
        break;
      case 'toggle-analytics':
        updateUI((ui) => ({ ...ui, isAnalyticsOpen: !ui.isAnalyticsOpen }));
        break;
      case 'toggle-template-panel':
        updateUI((ui) => ({
          ...ui,
          isTemplatePanelOpen: !ui.isTemplatePanelOpen,
        }));
        break;
      case 'toggle-header-customize':
        updateUI((ui) => ({
          ...ui,
          isHeaderCustomizeOpen: !ui.isHeaderCustomizeOpen,
        }));
        break;
      case 'export-notes':
        exportNotes();
        break;
      case 'import-notes':
        importNotes();
        break;
      case 'clear-filters':
        resetFilters();
        break;
      default:
        break;
    }
  }

  function toggleHeaderPin(actionId) {
    const pinned = [...state.headerConfig.pinned];
    const menu = [...state.headerConfig.menu];

    const inPinned = pinned.indexOf(actionId);
    const inMenu = menu.indexOf(actionId);

    if (inPinned !== -1) {
      pinned.splice(inPinned, 1);
      if (inMenu === -1) menu.push(actionId);
    } else if (inMenu !== -1) {
      menu.splice(inMenu, 1);
      pinned.push(actionId);
    } else {
      return;
    }

    setState({ headerConfig: { pinned, menu } });
  }

  function resetFilters() {
    updateUI((ui) => ({
      ...ui,
      query: '',
      searchScope: 'all',
      activeBucket: 'all',
      activeSort: 'smart',
      groupBy: 'none',
      activePriorityFilter: 'all',
      activeColorFilter: 'all',
      showFavoritesOnly: false,
      showPinnedOnly: false,
      showArchivedOnly: false,
      showTrashOnly: false,
      showChecklistOnly: false,
      showOverdueOnly: false,
      showTodayOnly: false,
    }));
  }

  /* =========================================================
   * Toast & Confirm (جایگزین سطح‌بالای alert/confirm)
   * ========================================================= */

  function showToast(message, kind = 'info', action = null) {
    const id = ++toastSeq;
    toasts = [...toasts, { id, message, kind, action }];
    syncToastLayer();

    const timer = window.setTimeout(() => dismissToast(id), TOAST_TTL_MS);
    toastTimers.set(id, timer);
  }

  function dismissToast(id) {
    const timer = toastTimers.get(id);
    if (timer) window.clearTimeout(timer);
    toastTimers.delete(id);
    toasts = toasts.filter((t) => t.id !== id);
    syncToastLayer();
  }

  function syncToastLayer() {
    const layer = root?.querySelector('.note-toast-layer');
    if (!layer) return;

    layer.innerHTML = toasts
      .map(
        (t) => `
        <div class="note-toast note-toast-${t.kind}" role="status">
          <span class="note-toast-dot" aria-hidden="true"></span>
          <span class="note-toast-msg">${escapeHtml(t.message)}</span>
          ${
            t.action
              ? `<button class="note-toast-action" data-action="toast-action" data-toast-id="${t.id}">${escapeHtml(
                  t.action.label
                )}</button>`
              : ''
          }
          <button class="note-toast-close" data-action="toast-dismiss" data-toast-id="${t.id}" aria-label="بستن">${icon(
            'x',
            14
          )}</button>
        </div>`
      )
      .join('');
  }

  function askConfirm({ title, message, confirmLabel = 'تأیید', danger = false }) {
    return new Promise((resolve) => {
      confirmState = { title, message, confirmLabel, danger };
      confirmResolver = resolve;
      syncModalLayer();
    });
  }

  function settleConfirm(result) {
    const resolver = confirmResolver;
    confirmState = null;
    confirmResolver = null;
    syncModalLayer();
    if (resolver) resolver(result);
  }

  function syncModalLayer() {
    const layer = root?.querySelector('.note-modals');
    if (layer) layer.innerHTML = renderModals();
  }

  /* =========================================================
   * محاسبات فیلتر / سورت / گروه‌بندی
   * ========================================================= */

  function isOverdue(dateString, note) {
    if (!dateString) return false;
    if (note && (note.trashed || note.status === 'done')) return false;
    const due = new Date(dateString).setHours(23, 59, 59, 999);
    return !Number.isNaN(due) && due < Date.now();
  }

  function isDueToday(dateString, note) {
    if (!dateString) return false;
    if (note && (note.trashed || note.status === 'done')) return false;
    const d = new Date(dateString);
    if (Number.isNaN(d.getTime())) return false;
    const now = new Date();
    return (
      d.getFullYear() === now.getFullYear() &&
      d.getMonth() === now.getMonth() &&
      d.getDate() === now.getDate()
    );
  }

  function getVisibleNotes() {
    let notes = Array.isArray(state.notes) ? [...state.notes] : [];
    const ui = state.ui;

    // در حالت‌های عادی، آیتم‌های سطل زباله نمایش داده نمی‌شوند
    if (!ui.showTrashOnly) {
      notes = notes.filter((n) => !n.trashed);
    } else {
      notes = notes.filter((n) => !!n.trashed);
    }

    if (ui.showFavoritesOnly) notes = notes.filter((n) => !!n.favorite);
    if (ui.showPinnedOnly) notes = notes.filter((n) => !!n.pinned);
    if (ui.showArchivedOnly) notes = notes.filter((n) => !!n.archived);
    if (ui.showChecklistOnly)
      notes = notes.filter(
        (n) => Array.isArray(n.checklist) && n.checklist.length > 0
      );
    if (ui.showOverdueOnly)
      notes = notes.filter((n) => isOverdue(n.dueAt, n));
    if (ui.showTodayOnly) notes = notes.filter((n) => isDueToday(n.dueAt, n));

    if (ui.activePriorityFilter !== 'all') {
      notes = notes.filter(
        (n) => (n.priority || '').toLowerCase() === ui.activePriorityFilter
      );
    }

    if (ui.activeColorFilter !== 'all') {
      notes = notes.filter(
        (n) => (n.color || '').toLowerCase() === ui.activeColorFilter
      );
    }

    if (String(ui.query || '').trim()) {
      notes = notes.filter((n) =>
        matchesSearch(n, ui.query, ui.searchScope)
      );
    }

    return sortNotes(notes, ui.activeSort);
  }

  function matchesSearch(note, query, scope) {
    const q = String(query || '').toLowerCase().trim();
    if (!q) return true;

    const title = (note.title || '').toLowerCase();
    const content = (note.content || '').toLowerCase();
    const tags = Array.isArray(note.tags)
      ? note.tags.join(' ').toLowerCase()
      : '';
    const category = (note.category || '').toLowerCase();
    const color = (note.color || '').toLowerCase();
    const date = [
      note.createdAt,
      note.updatedAt,
      note.dueAt,
      formatDateLong(note.dueAt),
      formatDateLong(note.updatedAt),
    ]
      .filter(Boolean)
      .join(' ')
      .toLowerCase();

    switch (scope) {
      case 'title':
        return title.includes(q);
      case 'content':
        return content.includes(q);
      case 'tags':
        return tags.includes(q);
      case 'category':
        return category.includes(q);
      case 'color':
        return (
          color.includes(q) ||
          (COLOR_LABELS[note.color] || '').toLowerCase().includes(q)
        );
      case 'date':
        return date.includes(q);
      case 'all':
      default:
        return [title, content, tags, category, color, date].some((v) =>
          v.includes(q)
        );
    }
  }

  function sortNotes(notes, sortMode) {
    const compareDateDesc = (a, b, key = 'updatedAt') =>
      new Date(b[key] || 0).getTime() - new Date(a[key] || 0).getTime();

    switch (sortMode) {
      case 'created':
        return notes.sort((a, b) => compareDateDesc(a, b, 'createdAt'));
      case 'updated':
        return notes.sort((a, b) => compareDateDesc(a, b, 'updatedAt'));
      case 'alphabetical':
        return notes.sort((a, b) =>
          (a.title || '').localeCompare(b.title || '', 'fa')
        );
      case 'priority':
        return notes.sort(
          (a, b) =>
            (PRIORITY_RANK[b.priority] || 0) - (PRIORITY_RANK[a.priority] || 0)
        );
      case 'due':
        return notes.sort((a, b) => {
          const da = a.dueAt
            ? new Date(a.dueAt).getTime()
            : Number.MAX_SAFE_INTEGER;
          const db = b.dueAt
            ? new Date(b.dueAt).getTime()
            : Number.MAX_SAFE_INTEGER;
          return da - db;
        });
      case 'pinned':
        return notes.sort((a, b) => Number(!!b.pinned) - Number(!!a.pinned));
      case 'favorite':
        return notes.sort(
          (a, b) => Number(!!b.favorite) - Number(!!a.favorite)
        );
      case 'neglected':
        return notes.sort((a, b) => {
          const da = new Date(a.updatedAt || a.createdAt || 0).getTime();
          const db = new Date(b.updatedAt || b.createdAt || 0).getTime();
          return da - db;
        });
      case 'momentum':
        return notes.sort((a, b) => {
          const sa =
            (a.checklist?.length || 0) + (a.content?.length || 0) / 100;
          const sb =
            (b.checklist?.length || 0) + (b.content?.length || 0) / 100;
          return sb - sa;
        });
      case 'random':
        return notes.sort(() => Math.random() - 0.5);
      case 'smart':
      default:
        return notes.sort((a, b) => {
          const pin = Number(!!b.pinned) - Number(!!a.pinned);
          if (pin !== 0) return pin;
          const fav = Number(!!b.favorite) - Number(!!a.favorite);
          if (fav !== 0) return fav;
          const pr =
            (PRIORITY_RANK[b.priority] || 0) - (PRIORITY_RANK[a.priority] || 0);
          if (pr !== 0) return pr;
          return compareDateDesc(a, b, 'updatedAt');
        });
    }
  }

  function groupNotes(notes) {
    const groupBy = state.ui.groupBy;
    if (groupBy === 'none') return { flattened: notes, groups: [] };

    const buckets = new Map();

    const getLabel = (note) => {
      switch (groupBy) {
        case 'status':
          return STATUS_LABELS[note.status] || 'در انتظار';
        case 'priority':
          return PRIORITY_LABELS[note.priority] || 'متوسط';
        case 'color':
          return COLOR_LABELS[note.color] || 'خاکستری';
        case 'category':
          return note.category || 'بدون دسته‌بندی';
        default:
          return 'سایر';
      }
    };

    for (const note of notes) {
      const key = getLabel(note);
      if (!buckets.has(key)) buckets.set(key, []);
      buckets.get(key).push(note);
    }

    return {
      flattened: notes,
      groups: Array.from(buckets.entries()).map(([label, items]) => ({
        label,
        items,
      })),
    };
  }

  function getSidebarStats() {
    const notes = Array.isArray(state.notes) ? state.notes : [];
    const alive = notes.filter((n) => !n.trashed);

    return {
      total: alive.length,
      favorites: alive.filter((n) => !!n.favorite).length,
      pinned: alive.filter((n) => !!n.pinned).length,
      archived: alive.filter((n) => !!n.archived).length,
      trashed: notes.filter((n) => !!n.trashed).length,
      withChecklist: alive.filter(
        (n) => Array.isArray(n.checklist) && n.checklist.length > 0
      ).length,
      overdue: alive.filter((n) => isOverdue(n.dueAt, n)).length,
      todayDue: alive.filter((n) => isDueToday(n.dueAt, n)).length,
    };
  }

  /* =========================================================
   * رندر
   * ========================================================= */

  function render() {
    return `
      <section
        id="${PAGE_ID}"
        class="note-page theme-${escapeHtml(state.ui.theme)}"
        data-density="${escapeHtml(state.ui.density)}"
        dir="rtl"
      >
        <div class="note-shell">
          ${renderHeader()}
          ${renderToolbarStatus()}
          <div class="note-layout">
            ${renderSidebar()}
            <main class="note-main">
              ${renderPanels()}
              <div class="note-active-view">
                ${renderActiveView()}
              </div>
            </main>
          </div>
          <div class="note-modals">${renderModals()}</div>
          <div class="note-toast-layer" aria-live="polite"></div>
        </div>
      </section>
    `;
  }

  /* ---------- Header ---------- */

  function renderHeader() {
    const pinnedActions = state.headerConfig.pinned
      .map((id) => renderHeaderActionButton(id, true))
      .join('');

    const menuActions = state.headerConfig.menu
      .map((id) => renderHeaderActionButton(id, false))
      .join('');

    const visibleCount = getVisibleNotes().length;

    return `
      <header class="note-header">
        <div class="note-header-top">
          <div class="note-header-brand">
            <div class="note-header-brand-icon">${icon('note', 22)}</div>
            <div class="note-header-brand-text">
              <h1>فضای کاری یادداشت‌ها</h1>
              <p>جستجو، برنامه‌ریزی، چک‌لیست، تحلیل و مدیریت هوشمند یادداشت‌ها</p>
            </div>
          </div>

          <div class="note-header-actions">
            ${pinnedActions}
            <div class="note-more-menu-wrap">
              <button class="note-header-btn" data-action="toggle-more-menu" aria-label="اقدامات بیشتر" aria-expanded="${
                state.ui.isMoreMenuOpen ? 'true' : 'false'
              }">
                <span class="note-header-btn-icon">${icon('dots', 18)}</span>
              </button>
              ${
                state.ui.isMoreMenuOpen
                  ? `
                <div class="note-more-menu" role="menu">
                  <div class="note-menu-title">اقدامات بیشتر</div>
                  ${menuActions}
                </div>`
                  : ''
              }
            </div>
          </div>
        </div>

        <div class="note-header-bottom">
          <div class="note-search-wrap">
            <span class="note-search-icon">${icon('search', 16)}</span>
            <input
              class="note-search-input"
              type="text"
              placeholder="جستجو در عنوان، محتوا، تگ، دسته‌بندی، رنگ یا تاریخ..."
              value="${escapeHtml(state.ui.query)}"
              data-input="search-query"
              aria-label="جستجوی یادداشت‌ها"
            />
            <select class="note-select note-search-scope" data-change="search-scope" aria-label="محدوده جستجو">
              ${renderOptions(SEARCH_SCOPE_OPTIONS, state.ui.searchScope)}
            </select>
          </div>

          <div class="note-header-meta">
            <span class="note-chip note-chip-accent">${faNumber(visibleCount)} قابل مشاهده</span>
            <span class="note-chip">${faNumber(getSidebarStats().total)} کل</span>
            <span class="note-chip">نما: ${escapeHtml(VIEW_LABELS[state.ui.activeView] || '')}</span>
            <span class="note-chip">مرتب‌سازی: ${escapeHtml(SORT_LABELS[state.ui.activeSort] || '')}</span>
          </div>
        </div>
      </header>
    `;
  }

  function renderHeaderActionButton(actionId, pinned) {
    const meta = getHeaderActionMeta(actionId);
    if (!meta) return '';

    return `
      <button
        class="note-header-btn ${pinned ? 'is-pinned' : 'note-menu-item'}"
        data-action="header-action"
        data-header-action-id="${escapeHtml(actionId)}"
        title="${escapeHtml(meta.title)}"
        aria-label="${escapeHtml(meta.title)}"
      >
        <span class="note-header-btn-icon">${icon(meta.icon, 16)}</span>
        <span class="note-header-btn-label">${escapeHtml(meta.label)}</span>
      </button>
    `;
  }

  /* ---------- Toolbar ---------- */

  function renderToolbarStatus() {
    const selectedCount = state.ui.selectedIds.length;
    const ui = state.ui;

    return `
      <section class="note-toolbar-status">
        <div class="note-toolbar-left" role="tablist" aria-label="حالت نمایش">
          ${VIEW_OPTIONS.map(
            ([value, label]) => `
            <button
              class="note-tab ${ui.activeView === value ? 'active' : ''}"
              data-action="set-view"
              data-view="${escapeHtml(value)}"
              role="tab"
              aria-selected="${ui.activeView === value ? 'true' : 'false'}"
            >
              ${icon(VIEW_ICONS[value] || 'grid', 14)}
              <span>${escapeHtml(label)}</span>
            </button>`
          ).join('')}
        </div>

        <div class="note-toolbar-right">
          <select class="note-select" data-change="sort" aria-label="مرتب‌سازی">
            ${renderOptions(SORT_OPTIONS, ui.activeSort)}
          </select>

          <select class="note-select" data-change="group-by" aria-label="گروه‌بندی">
            ${renderOptions(GROUP_OPTIONS, ui.groupBy)}
          </select>

          <button class="note-btn" data-action="toggle-filter-panel" aria-expanded="${
            ui.isFilterPanelOpen ? 'true' : 'false'
          }">
            ${icon('filter', 14)} فیلترها
          </button>

          <button class="note-btn ${ui.selectionMode ? 'is-active' : ''}" data-action="toggle-selection-mode">
            ${icon('check', 14)}
            ${selectedCount ? `انتخاب: ${faNumber(selectedCount)}` : 'انتخاب'}
          </button>

          <button class="note-btn note-btn-primary" data-action="open-quick-add">
            ${icon('plus', 14)} یادداشت جدید
          </button>
        </div>
      </section>
    `;
  }

  /* ---------- Sidebar ---------- */

  function renderSidebar() {
    const counts = getSidebarStats();
    const ui = state.ui;

    const statDefs = [
      {
        label: 'همه یادداشت‌ها',
        count: counts.total,
        action: 'show-all',
        active:
          ui.activeBucket === 'all' &&
          !Object.values({
            a: ui.showFavoritesOnly,
            b: ui.showPinnedOnly,
            c: ui.showArchivedOnly,
            d: ui.showTrashOnly,
            e: ui.showChecklistOnly,
            f: ui.showOverdueOnly,
            g: ui.showTodayOnly,
          }).some(Boolean),
        icon: 'note',
      },
      {
        label: 'علاقه‌مندی‌ها',
        count: counts.favorites,
        action: 'toggle-favorites',
        active: ui.showFavoritesOnly,
        icon: 'star',
      },
      {
        label: 'سنجاق‌شده',
        count: counts.pinned,
        action: 'toggle-pinned-filter',
        active: ui.showPinnedOnly,
        icon: 'pin',
      },
      {
        label: 'بایگانی',
        count: counts.archived,
        action: 'toggle-archive',
        active: ui.showArchivedOnly,
        icon: 'archive',
      },
      {
        label: 'سطل زباله',
        count: counts.trashed,
        action: 'toggle-trash',
        active: ui.showTrashOnly,
        icon: 'trash',
      },
      {
        label: 'دارای چک‌لیست',
        count: counts.withChecklist,
        action: 'toggle-checklist-filter',
        active: ui.showChecklistOnly,
        icon: 'checklist',
      },
      {
        label: 'موعد گذشته',
        count: counts.overdue,
        action: 'filter-overdue',
        active: ui.showOverdueOnly,
        icon: 'alert',
      },
      {
        label: 'موعد امروز',
        count: counts.todayDue,
        action: 'filter-today',
        active: ui.showTodayOnly,
        icon: 'clock',
      },
    ];

    return `
      <aside class="note-sidebar">
        <section class="note-side-card">
          <h3>سطل‌های هوشمند</h3>
          <div class="note-side-list">
            ${statDefs
              .map(
                (s) => `
              <button class="note-side-stat ${s.active ? 'active' : ''}" data-action="${s.action}">
                <span class="note-side-stat-label">${icon(s.icon, 14)} ${escapeHtml(s.label)}</span>
                <strong>${faNumber(s.count)}</strong>
              </button>`
              )
              .join('')}
          </div>
          ${
            ui.showTrashOnly && counts.trashed > 0
              ? `<button class="note-btn note-btn-danger note-side-danger" data-action="empty-trash">
                  ${icon('trash', 14)} خالی کردن سطل زباله
                </button>`
              : ''
          }
        </section>

        <section class="note-side-card">
          <h3>فیلتر رنگ</h3>
          <div class="note-filter-grid">
            ${COLOR_KEYS.map((color) => renderColorFilter(color)).join('')}
          </div>
        </section>

        <section class="note-side-card">
          <h3>اولویت</h3>
          <div class="note-side-list">
            ${PRIORITY_KEYS.map((p) => renderPriorityFilter(p)).join('')}
          </div>
        </section>

        <section class="note-side-card">
          <h3>قالب‌های آماده</h3>
          <div class="note-template-mini-actions">
            <button class="note-btn" data-action="create-template-daily">مرور روزانه</button>
            <button class="note-btn" data-action="create-template-project">برنامه‌ریزی پروژه</button>
            <button class="note-btn" data-action="create-template-brainstorm">طوفان فکری</button>
            <button class="note-btn" data-action="create-template-meeting">صورت‌جلسه</button>
          </div>
        </section>
      </aside>
    `;
  }

  function renderColorFilter(color) {
    const active = state.ui.activeColorFilter === color ? 'active' : '';
    return `
      <button class="note-color-filter ${active}" data-action="set-color-filter" data-color="${escapeHtml(color)}">
        <span class="note-color-dot note-color-${escapeHtml(color)}"></span>
        <span>${escapeHtml(COLOR_LABELS[color] || color)}</span>
      </button>
    `;
  }

  function renderPriorityFilter(priority) {
    const active = state.ui.activePriorityFilter === priority ? 'active' : '';
    return `
      <button class="note-priority-filter ${active}" data-action="set-priority-filter" data-priority="${escapeHtml(
      priority
    )}">
        ${escapeHtml(PRIORITY_LABELS[priority] || priority)}
      </button>
    `;
  }

  /* ---------- Panels ---------- */

  function renderPanels() {
    const ui = state.ui;
    return `
      <div class="note-top-panels">
        ${ui.isFilterPanelOpen ? renderFilterPanel() : ''}
        ${ui.isBulkBarOpen ? renderBulkPanel() : ''}
        ${ui.isAnalyticsOpen ? renderAnalyticsPanel() : ''}
        ${ui.isTemplatePanelOpen ? renderTemplatePanel() : ''}
        ${ui.isHeaderCustomizeOpen ? renderHeaderCustomizePanel() : ''}
      </div>
    `;
  }

  function renderFilterPanel() {
    const ui = state.ui;

    const toggles = [
      ['toggle-favorites', 'فقط علاقه‌مندی‌ها', ui.showFavoritesOnly],
      ['toggle-pinned-filter', 'فقط سنجاق‌شده‌ها', ui.showPinnedOnly],
      ['toggle-archive', 'فقط بایگانی', ui.showArchivedOnly],
      ['toggle-trash', 'فقط سطل زباله', ui.showTrashOnly],
      ['toggle-checklist-filter', 'فقط دارای چک‌لیست', ui.showChecklistOnly],
      ['filter-overdue', 'فقط موعد گذشته', ui.showOverdueOnly],
      ['filter-today', 'فقط موعد امروز', ui.showTodayOnly],
    ];

    return `
      <section class="note-panel">
        <div class="note-panel-head">
          <h3>${icon('filter', 16)} فیلترهای پیشرفته</h3>
          <div class="note-panel-head-actions">
            <button class="note-btn" data-action="clear-filters">${icon('refresh', 14)} ریست همه</button>
            <button class="note-btn" data-action="close-filter-panel">${icon('x', 14)} بستن</button>
          </div>
        </div>
        <div class="note-panel-body">
          <div class="note-filter-toggle-grid">
            ${toggles
              .map(
                ([action, label, on]) => `
              <button class="note-filter-toggle ${on ? 'active' : ''}" data-action="${action}">
                <span class="note-filter-toggle-dot"></span>
                ${escapeHtml(label)}
              </button>`
              )
              .join('')}
          </div>
          <p class="note-panel-hint">فیلترها با جستجو، مرتب‌سازی و گروه‌بندی ترکیب می‌شوند.</p>
        </div>
      </section>
    `;
  }

  function renderBulkPanel() {
    const count = state.ui.selectedIds.length;
    const inTrash = state.ui.showTrashOnly;

    return `
      <section class="note-panel note-panel-accent">
        <div class="note-panel-head">
          <h3>${icon('check', 16)} عملیات گروهی</h3>
          <span class="note-chip">${faNumber(count)} انتخاب شده</span>
        </div>
        <div class="note-panel-body note-bulk-actions">
          <button class="note-btn" data-action="bulk-pin">${icon('pin', 14)} سنجاق</button>
          <button class="note-btn" data-action="bulk-favorite">${icon('star', 14)} علاقه‌مندی</button>
          ${
            inTrash
              ? `
            <button class="note-btn" data-action="bulk-restore">${icon('undo', 14)} بازیابی</button>
            <button class="note-btn note-btn-danger" data-action="bulk-delete-permanent">${icon('trash', 14)} حذف دائمی</button>
          `
              : `
            <button class="note-btn" data-action="bulk-archive">${icon('archive', 14)} بایگانی</button>
            <button class="note-btn note-btn-danger" data-action="bulk-trash">${icon('trash', 14)} سطل زباله</button>
          `
          }
          <button class="note-btn" data-action="bulk-select-all">${icon('checklist', 14)} انتخاب همه نتایج</button>
          <button class="note-btn" data-action="bulk-clear">${icon('x', 14)} لغو انتخاب</button>
        </div>
      </section>
    `;
  }

  function renderAnalyticsPanel() {
    const stats = getSidebarStats();
    const visible = getVisibleNotes();
    const alive = state.notes.filter((n) => !n.trashed);

    const statusCounts = STATUS_KEYS.map(
      (key) => [key, alive.filter((n) => n.status === key).length]
    );
    const priorityCounts = [...PRIORITY_KEYS]
      .reverse()
      .map((key) => [key, alive.filter((n) => n.priority === key).length]);

    const maxStatus = Math.max(1, ...statusCounts.map(([, c]) => c));
    const maxPriority = Math.max(1, ...priorityCounts.map(([, c]) => c));

    const totalChecks = alive.reduce((s, n) => s + n.checklist.length, 0);
    const doneChecks = alive.reduce(
      (s, n) => s + n.checklist.filter((c) => c.done).length,
      0
    );
    const checkRate = totalChecks
      ? Math.round((doneChecks / totalChecks) * 100)
      : 0;

    const weekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
    const createdThisWeek = alive.filter(
      (n) => new Date(n.createdAt || 0).getTime() >= weekAgo
    ).length;

    return `
      <section class="note-panel">
        <div class="note-panel-head">
          <h3>${icon('chart', 16)} تحلیل فضای کاری</h3>
          <button class="note-btn" data-action="toggle-analytics">${icon('x', 14)} بستن</button>
        </div>
        <div class="note-panel-body">
          <div class="note-analytics-grid">
            ${renderAnalyticsCard(visible.length, 'قابل مشاهده')}
            ${renderAnalyticsCard(stats.pinned, 'سنجاق‌شده')}
            ${renderAnalyticsCard(stats.overdue, 'موعد گذشته')}
            ${renderAnalyticsCard(stats.todayDue, 'موعد امروز')}
            ${renderAnalyticsCard(createdThisWeek, 'ایجاد در ۷ روز اخیر')}
            ${renderAnalyticsCard(`${checkRate}٪`, 'پیشرفت چک‌لیست‌ها')}
          </div>

          <div class="note-analytics-bars">
            <div class="note-analytics-col">
              <h4>توزیع وضعیت</h4>
              ${statusCounts
                .map(
                  ([key, count]) => `
                <div class="note-bar-row">
                  <span class="note-bar-label">${escapeHtml(STATUS_LABELS[key])}</span>
                  <span class="note-bar-track">
                    <span class="note-bar-fill" style="width:${Math.round(
                      (count / maxStatus) * 100
                    )}%"></span>
                  </span>
                  <span class="note-bar-value">${faNumber(count)}</span>
                </div>`
                )
                .join('')}
            </div>

            <div class="note-analytics-col">
              <h4>توزیع اولویت</h4>
              ${priorityCounts
                .map(
                  ([key, count]) => `
                <div class="note-bar-row">
                  <span class="note-bar-label">${escapeHtml(PRIORITY_LABELS[key])}</span>
                  <span class="note-bar-track">
                    <span class="note-bar-fill note-bar-fill-${escapeHtml(
                      key
                    )}" style="width:${Math.round((count / maxPriority) * 100)}%"></span>
                  </span>
                  <span class="note-bar-value">${faNumber(count)}</span>
                </div>`
                )
                .join('')}
            </div>
          </div>
        </div>
      </section>
    `;
  }

  function renderAnalyticsCard(value, label) {
    const display =
      typeof value === 'number' ? faNumber(value) : escapeHtml(value);
    return `
      <div class="note-analytics-card">
        <strong>${display}</strong>
        <span>${escapeHtml(label)}</span>
      </div>
    `;
  }

  function renderTemplatePanel() {
    const templates = [
      {
        action: 'create-template-daily',
        title: 'مرور روزانه',
        desc: 'اولویت‌ها، بازتاب و برنامه فردا',
        icon: 'sun',
      },
      {
        action: 'create-template-project',
        title: 'برنامه‌ریزی پروژه',
        desc: 'دامنه، نقاط عطف و ریسک‌ها',
        icon: 'board',
      },
      {
        action: 'create-template-brainstorm',
        title: 'طوفان فکری',
        desc: 'ایده‌پردازی آزاد و سریع',
        icon: 'zap',
      },
      {
        action: 'create-template-meeting',
        title: 'صورت‌جلسه',
        desc: 'دستور جلسه، تصمیمات، اقدامات',
        icon: 'checklist',
      },
    ];

    return `
      <section class="note-panel">
        <div class="note-panel-head">
          <h3>${icon('layers', 16)} قالب‌های آماده</h3>
          <button class="note-btn" data-action="toggle-template-panel">${icon('x', 14)} بستن</button>
        </div>
        <div class="note-panel-body">
          <div class="note-template-grid">
            ${templates
              .map(
                (t) => `
              <button class="note-template-card" data-action="${t.action}">
                <span class="note-template-icon">${icon(t.icon, 18)}</span>
                <strong>${escapeHtml(t.title)}</strong>
                <span>${escapeHtml(t.desc)}</span>
              </button>`
              )
              .join('')}
          </div>
        </div>
      </section>
    `;
  }

  function renderHeaderCustomizePanel() {
    const allIds = [
      'toggle-theme',
      'toggle-density',
      'toggle-analytics',
      'toggle-template-panel',
      'toggle-header-customize',
      'export-notes',
      'import-notes',
      'clear-filters',
    ];

    return `
      <section class="note-panel">
        <div class="note-panel-head">
          <h3>${icon('sliders', 16)} شخصی‌سازی هدر</h3>
          <button class="note-btn" data-action="toggle-header-customize">${icon('x', 14)} بستن</button>
        </div>
        <div class="note-panel-body">
          <p class="note-panel-hint">اکشن‌ها را بین ناحیه «سنجاق‌شده در هدر» و «منوی بیشتر» جابه‌جا کنید.</p>
          <div class="note-customize-list">
            ${allIds
              .map((id) => {
                const meta = getHeaderActionMeta(id);
                if (!meta) return '';
                const isPinned = state.headerConfig.pinned.includes(id);
                return `
                  <div class="note-customize-row">
                    <span class="note-customize-label">${icon(meta.icon, 14)} ${escapeHtml(meta.label)}</span>
                    <button class="note-btn" data-action="header-pin-toggle" data-header-action-id="${escapeHtml(id)}">
                      ${isPinned ? 'انتقال به منو' : 'سنجاق به هدر'}
                    </button>
                  </div>
                `;
              })
              .join('')}
          </div>
        </div>
      </section>
    `;
  }

  /* ---------- Active view ---------- */

  function renderActiveView() {
    if (isLoading && !hasLoaded) return renderSkeleton();
    if (loadError) return renderLoadError();

    const notes = getVisibleNotes();

    if (!notes.length) {
      return `
        <section class="note-empty-state">
          <div class="note-empty-icon">${icon('inbox', 44)}</div>
          <h2>یادداشتی یافت نشد</h2>
          <p>فیلترها یا عبارت جستجو را تغییر دهید یا یک یادداشت تازه بسازید.</p>
          <button class="note-btn note-btn-primary" data-action="open-quick-add">
            ${icon('plus', 14)} ساخت یادداشت
          </button>
        </section>
      `;
    }

    switch (state.ui.activeView) {
      case 'list':
        return renderListView(groupNotes(notes));
      case 'board':
        return renderBoardView(notes);
      case 'timeline':
        return renderTimelineView(notes);
      case 'calendar':
        return renderCalendarView(notes);
      case 'masonry':
        return renderMasonryView(notes);
      case 'grid':
      default:
        return renderGridView(groupNotes(notes));
    }
  }

  function renderSkeleton() {
    return `
      <div class="note-skeleton-grid" aria-busy="true" aria-label="در حال بارگذاری">
        ${Array.from({ length: 6 })
          .map(
            () => `
          <div class="note-skeleton-card">
            <span class="note-skel note-skel-title"></span>
            <span class="note-skel note-skel-line"></span>
            <span class="note-skel note-skel-line short"></span>
            <span class="note-skel note-skel-footer"></span>
          </div>`
          )
          .join('')}
      </div>
    `;
  }

  function renderLoadError() {
    return `
      <section class="note-empty-state">
        <div class="note-empty-icon">${icon('alert', 44)}</div>
        <h2>خطا در بارگذاری</h2>
        <p>${escapeHtml(loadError)}</p>
        <button class="note-btn note-btn-primary" data-action="retry-load">
          ${icon('refresh', 14)} تلاش مجدد
        </button>
      </section>
    `;
  }

  function renderGridView(grouped) {
    return `<div class="note-grid-view">${renderGroupedSections(
      grouped,
      'note-grid'
    )}</div>`;
  }

  function renderListView(grouped) {
    return `<div class="note-list-view">${renderGroupedSections(
      grouped,
      'note-list'
    )}</div>`;
  }

  function renderBoardView(notes) {
    const byStatus = STATUS_KEYS.reduce((acc, key) => {
      acc[key] = notes.filter((n) => (n.status || 'todo') === key);
      return acc;
    }, {});

    return `
      <div class="note-board-view">
        ${STATUS_KEYS.map((status) => {
          const items = byStatus[status] || [];
          return `
            <section class="note-board-column" data-status="${escapeHtml(status)}">
              <div class="note-board-head">
                <h3>${escapeHtml(STATUS_LABELS[status])}</h3>
                <span class="note-chip">${faNumber(items.length)}</span>
              </div>
              <div class="note-board-body" data-status="${escapeHtml(status)}">
                ${items.map((note) => renderNoteCard(note, { draggable: true })).join('')}
              </div>
            </section>`;
        }).join('')}
      </div>
    `;
  }

  function renderTimelineView(notes) {
    const sorted = sortNotes([...notes], 'updated');

    return `
      <div class="note-timeline-view">
        ${sorted
          .map((note) => {
            const stamp = note.updatedAt || note.createdAt;
            return `
            <article class="note-timeline-item">
              <div class="note-timeline-dot note-color-${escapeHtml(note.color)}"></div>
              <div class="note-timeline-card">
                <div class="note-card-head">
                  <h3 class="note-card-title">${escapeHtml(note.title || 'بدون عنوان')}</h3>
                  <span class="note-chip">${escapeHtml(formatDateShort(stamp))}</span>
                </div>
                <p class="note-card-preview">${escapeHtml(getPreview(note.content))}</p>
                <div class="note-card-footer">
                  <span class="note-chip">${escapeHtml(relativeTime(stamp))}</span>
                  <div class="note-card-actions">
                    <button class="note-mini-btn" data-action="edit-note" data-note-id="${escapeHtml(note.id)}">ویرایش</button>
                  </div>
                </div>
              </div>
            </article>`;
          })
          .join('')}
      </div>
    `;
  }

  function renderCalendarView(notes) {
    const buckets = new Map();
    for (const note of notes) {
      const key = note.dueAt || '';
      if (!buckets.has(key)) buckets.set(key, []);
      buckets.get(key).push(note);
    }

    const entries = Array.from(buckets.entries()).sort(([a], [b]) => {
      if (!a) return 1;
      if (!b) return -1;
      return new Date(a).getTime() - new Date(b).getTime();
    });

    return `
      <div class="note-calendar-view">
        ${entries
          .map(([dateKey, items]) => {
            const label = dateKey ? formatDateLong(dateKey) : 'بدون موعد';
            return `
            <section class="note-calendar-day">
              <div class="note-calendar-head">
                <h3>${escapeHtml(label)}</h3>
                <span class="note-chip">${faNumber(items.length)}</span>
              </div>
              <div class="note-calendar-list">
                ${items.map((note) => renderNoteCard(note)).join('')}
              </div>
            </section>`;
          })
          .join('')}
      </div>
    `;
  }

  function renderMasonryView(notes) {
    const sorted = sortNotes([...notes], 'smart');
    return `
      <div class="note-masonry-view">
        ${sorted.map((note) => renderNoteCard(note)).join('')}
      </div>
    `;
  }

  function renderGroupedSections(grouped, wrapperClass) {
    if (state.ui.groupBy === 'none') {
      return `
        <section class="${escapeHtml(wrapperClass)}">
          ${grouped.flattened.map((note) => renderNoteCard(note)).join('')}
        </section>
      `;
    }

    return `
      <div class="note-grouped-layout">
        ${grouped.groups
          .map(
            (group) => `
          <section class="note-group-section">
            <div class="note-group-head">
              <h3>${escapeHtml(group.label)}</h3>
              <span class="note-chip">${faNumber(group.items.length)}</span>
            </div>
            <div class="${escapeHtml(wrapperClass)}">
              ${group.items.map((note) => renderNoteCard(note)).join('')}
            </div>
          </section>`
          )
          .join('')}
      </div>
    `;
  }

  /* ---------- Note Card ---------- */

  function renderNoteCard(note, { draggable = false } = {}) {
    const selected = state.ui.selectedIds
      .map(String)
      .includes(String(note.id));

    const status = STATUS_LABELS[note.status] || 'در انتظار';
    const priority = PRIORITY_LABELS[note.priority] || 'متوسط';
    const preview = getPreview(note.content);
    const due = note.dueAt ? formatDateShort(note.dueAt) : 'بدون موعد';
    const overdue = isOverdue(note.dueAt, note);

    const checks = Array.isArray(note.checklist) ? note.checklist : [];
    const doneChecks = checks.filter((c) => c.done).length;
    const checkRate = checks.length
      ? Math.round((doneChecks / checks.length) * 100)
      : 0;

    return `
      <article
        class="note-card note-color-${escapeHtml(note.color)} ${selected ? 'selected' : ''} ${
      note.trashed ? 'is-trashed' : ''
    }"
        ${draggable ? 'draggable="true"' : ''}
        data-note-id="${escapeHtml(note.id)}"
      >
        <div class="note-card-head">
          <div class="note-card-title-wrap">
            <h3 class="note-card-title">${escapeHtml(note.title || 'بدون عنوان')}</h3>
            <div class="note-card-meta">
              <span class="note-chip">${escapeHtml(status)}</span>
              <span class="note-chip note-chip-priority-${escapeHtml(note.priority)}">${escapeHtml(priority)}</span>
              ${note.pinned ? `<span class="note-chip note-chip-flag">${icon('pin', 11)} سنجاق</span>` : ''}
              ${note.favorite ? `<span class="note-chip note-chip-flag">${icon('star', 11)}</span>` : ''}
              ${overdue ? `<span class="note-chip note-chip-overdue">${icon('alert', 11)} موعد گذشته</span>` : ''}
            </div>
          </div>

          ${
            state.ui.selectionMode
              ? `
            <input
              type="checkbox"
              class="note-select-box"
              data-action="toggle-select-note"
              data-note-id="${escapeHtml(note.id)}"
              ${selected ? 'checked' : ''}
              aria-label="انتخاب یادداشت"
            />`
              : ''
          }
        </div>

        <p class="note-card-preview">${escapeHtml(preview)}</p>

        ${
          checks.length
            ? `
          <div class="note-check">
            <div class="note-check-progress">
              <span class="note-check-track">
                <span class="note-check-fill" style="width:${checkRate}%"></span>
              </span>
              <span class="note-check-label">${faNumber(doneChecks)}/${faNumber(checks.length)}</span>
            </div>
            <ul class="note-check-list">
              ${checks
                .slice(0, 3)
                .map(
                  (item) => `
                <li class="note-check-item ${item.done ? 'done' : ''}">
                  <button
                    class="note-check-toggle"
                    data-action="toggle-check-item"
                    data-note-id="${escapeHtml(note.id)}"
                    data-check-id="${escapeHtml(item.id)}"
                    aria-label="${item.done ? 'برگرداندن' : 'تکمیل'}"
                  >
                    ${item.done ? icon('check', 12) : ''}
                  </button>
                  <span>${escapeHtml(item.text)}</span>
                </li>`
                )
                .join('')}
              ${
                checks.length > 3
                  ? `<li class="note-check-more">+ ${faNumber(checks.length - 3)} مورد دیگر</li>`
                  : ''
              }
            </ul>
          </div>`
            : ''
        }

        ${
          Array.isArray(note.tags) && note.tags.length
            ? `
          <div class="note-tags">
            ${note.tags
              .slice(0, 5)
              .map(
                (tag) =>
                  `<span class="note-tag">#${escapeHtml(tag)}</span>`
              )
              .join('')}
          </div>`
            : ''
        }

        <div class="note-card-footer">
          <span class="note-chip ${overdue ? 'note-chip-overdue' : ''}">${icon('calendar', 11)} ${escapeHtml(
      due
    )}</span>
          <div class="note-card-actions">
            ${
              state.ui.selectionMode
                ? `<button class="note-mini-btn" data-action="toggle-select-note" data-note-id="${escapeHtml(
                    note.id
                  )}">${selected ? 'لغو' : 'انتخاب'}</button>`
                : ''
            }
            ${
              note.trashed
                ? `
              <button class="note-mini-btn" data-action="restore-note" data-note-id="${escapeHtml(
                note.id
              )}">بازیابی</button>
              <button class="note-mini-btn note-mini-btn-danger" data-action="delete-note" data-note-id="${escapeHtml(
                note.id
              )}">حذف دائمی</button>
            `
                : `
              <button class="note-mini-btn" data-action="edit-note" data-note-id="${escapeHtml(note.id)}">ویرایش</button>
              <button class="note-mini-btn" data-action="toggle-pin" data-note-id="${escapeHtml(
                note.id
              )}">${note.pinned ? 'برداشتن سنجاق' : 'سنجاق'}</button>
              <button class="note-mini-btn" data-action="toggle-favorite-note" data-note-id="${escapeHtml(
                note.id
              )}">${note.favorite ? 'حذف علاقه‌مندی' : 'علاقه‌مندی'}</button>
              <button class="note-mini-btn" data-action="duplicate-note" data-note-id="${escapeHtml(
                note.id
              )}">کپی</button>
              <button class="note-mini-btn note-mini-btn-danger" data-action="delete-note" data-note-id="${escapeHtml(
                note.id
              )}">حذف</button>
            `
            }
          </div>
        </div>
      </article>
    `;
  }

  /* ---------- Modals ---------- */

  function renderModals() {
    const parts = [];

    if (state.ui.isQuickAddOpen) {
      parts.push(renderNoteModal());
    }

    if (confirmState) {
      parts.push(`
        <div class="note-modal-overlay note-confirm-overlay" data-confirm-overlay>
          <div class="note-modal-card note-confirm-card" role="alertdialog" aria-modal="true">
            <div class="note-modal-head">
              <h2>${escapeHtml(confirmState.title)}</h2>
            </div>
            <div class="note-modal-body">
              <p class="note-confirm-msg">${escapeHtml(confirmState.message)}</p>
              <div class="note-modal-actions">
                <button class="note-btn" data-action="confirm-cancel">انصراف</button>
                <button class="note-btn ${
                  confirmState.danger ? 'note-btn-danger' : 'note-btn-primary'
                }" data-action="confirm-accept">
                  ${escapeHtml(confirmState.confirmLabel)}
                </button>
              </div>
            </div>
          </div>
        </div>
      `);
    }

    return parts.join('');
  }

  function renderNoteModal() {
    const draft = state.ui.draftNote || createEmptyDraft();
    const isEditing = Boolean(state.ui.editingNoteId);
    const draftChecks = Array.isArray(draft.checklist) ? draft.checklist : [];

    const contentText = String(draft.content || '');
    const wordCount = contentText.trim()
      ? contentText.trim().split(/\s+/).length
      : 0;
    const charCount = contentText.length;

    return `
      <div class="note-modal-overlay" id="note-modal-overlay">
        <div class="note-modal-card" role="dialog" aria-modal="true" aria-label="${
          isEditing ? 'ویرایش یادداشت' : 'یادداشت جدید'
        }">
          <div class="note-modal-head">
            <h2>${isEditing ? 'ویرایش یادداشت' : 'یادداشت جدید'}</h2>
            <button class="note-btn" data-action="close-modal">${icon('x', 14)} بستن</button>
          </div>

          <div class="note-modal-body">
            <input
              class="note-modal-input"
              type="text"
              placeholder="عنوان یادداشت"
              data-input="quick-note-title"
              value="${escapeHtml(draft.title)}"
            />

            <textarea
              class="note-modal-textarea"
              placeholder="محتوای یادداشت..."
              rows="6"
              data-input="quick-note-content"
            >${escapeHtml(draft.content)}</textarea>

            <div class="note-modal-grid">
              <input
                class="note-modal-input"
                type="text"
                placeholder="دسته‌بندی"
                data-input="quick-note-category"
                value="${escapeHtml(draft.category)}"
              />

              <input
                class="note-modal-input"
                type="date"
                data-input="quick-note-dueAt"
                value="${escapeHtml(draft.dueAt)}"
                aria-label="موعد"
              />

              <input
                class="note-modal-input"
                type="text"
                placeholder="تگ‌ها: کار, ایده, فوری"
                data-input="quick-note-tags"
                value="${escapeHtml(draft.tags)}"
              />

              <select class="note-select" data-change="quick-note-priority" aria-label="اولویت">
                ${renderOptions(
                  PRIORITY_KEYS.map((k) => [k, PRIORITY_LABELS[k]]),
                  draft.priority
                )}
              </select>

              <select class="note-select" data-change="quick-note-color" aria-label="رنگ">
                ${renderOptions(
                  COLOR_KEYS.map((k) => [k, COLOR_LABELS[k]]),
                  draft.color
                )}
              </select>

              <select class="note-select" data-change="quick-note-status" aria-label="وضعیت">
                ${renderOptions(
                  STATUS_KEYS.map((k) => [k, STATUS_LABELS[k]]),
                  draft.status
                )}
              </select>
            </div>

            <div class="note-check-editor">
              <div class="note-check-editor-head">
                ${icon('checklist', 15)}
                <span>چک‌لیست</span>
              </div>

              ${
                draftChecks.length
                  ? `
                <ul class="note-check-editor-list">
                  ${draftChecks
                    .map(
                      (item) => `
                    <li class="note-check-editor-row ${item.done ? 'done' : ''}">
                      <button
                        class="note-check-toggle"
                        data-action="draft-check-toggle"
                        data-check-id="${escapeHtml(item.id)}"
                        aria-label="تغییر وضعیت"
                      >${item.done ? icon('check', 12) : ''}</button>
                      <span>${escapeHtml(item.text)}</span>
                      <button
                        class="note-check-remove"
                        data-action="draft-check-remove"
                        data-check-id="${escapeHtml(item.id)}"
                        aria-label="حذف مورد"
                      >${icon('x', 12)}</button>
                    </li>`
                    )
                    .join('')}
                </ul>`
                  : ''
              }

              <div class="note-check-new-row">
                <input
                  class="note-modal-input"
                  type="text"
                  placeholder="مورد جدید چک‌لیست + Enter"
                  data-input="quick-check-new"
                />
                <button class="note-btn" data-action="draft-check-add">${icon('plus', 14)} افزودن</button>
              </div>
            </div>

            <div class="note-modal-meta">
              <span class="note-chip">${faNumber(wordCount)} کلمه</span>
              <span class="note-chip">${faNumber(charCount)} نویسه</span>
              <span class="note-kbd-hint">Ctrl + Enter برای ذخیره</span>
            </div>

            <div class="note-modal-actions">
              <button class="note-btn" data-action="close-modal">انصراف</button>
              <button class="note-btn note-btn-primary" data-action="save-quick-note">
                ${icon('check', 14)} ${isEditing ? 'ذخیره تغییرات' : 'ذخیره یادداشت'}
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  /* =========================================================
   * رندر مجدد + حفظ فوکوس
   * ========================================================= */

  function getContainer() {
    return (
      document.getElementById('page-content') ||
      root?.parentElement ||
      null
    );
  }

  function rerender(options = {}) {
    const { preserveFocus = true } = options;
    if (isDestroyed) return;

    const container = getContainer();
    if (!container) return;

    const focusData = preserveFocus
      ? captureFocus(document.activeElement)
      : null;

    container.innerHTML = render();
    attachRoot();

    if (focusData) {
      window.requestAnimationFrame(() => restoreFocus(focusData));
    }
  }

  function captureFocus(element) {
    if (!element || !root || !root.contains(element)) return null;

    const inputType = element.dataset?.input;
    const changeType = element.dataset?.change;
    if (!inputType && !changeType) return null;

    return {
      inputType: inputType || null,
      changeType: changeType || null,
      selectionStart:
        typeof element.selectionStart === 'number'
          ? element.selectionStart
          : null,
      selectionEnd:
        typeof element.selectionEnd === 'number' ? element.selectionEnd : null,
    };
  }

  function restoreFocus(focusData) {
    if (!focusData || !root) return;

    const selector = focusData.inputType
      ? `[data-input="${focusData.inputType}"]`
      : focusData.changeType
        ? `[data-change="${focusData.changeType}"]`
        : null;

    if (!selector) return;

    const element = root.querySelector(selector);
    if (!element) return;

    element.focus({ preventScroll: true });

    if (
      typeof element.setSelectionRange === 'function' &&
      focusData.selectionStart !== null &&
      typeof element.value === 'string'
    ) {
      try {
        element.setSelectionRange(
          Math.min(focusData.selectionStart, element.value.length),
          Math.min(focusData.selectionEnd ?? focusData.selectionStart, element.value.length)
        );
      } catch {
        /* بعضی inputها (مثل date) selection ندارند */
      }
    }
  }

  /* =========================================================
   * رویدادها (Event Delegation)
   * ========================================================= */

  function handleClick(e) {
    // بستن مودال با کلیک روی پس‌زمینه
    if (
      e.target instanceof HTMLElement &&
      e.target.id === 'note-modal-overlay' &&
      state.ui.isQuickAddOpen
    ) {
      closeQuickModal();
      return;
    }

    const actionEl = e.target.closest?.('[data-action]');
    if (!actionEl || !root?.contains(actionEl)) return;

    const action = actionEl.dataset.action;
    const noteId = actionEl.dataset.noteId;

    switch (action) {
      /* --- منوها و پنل‌ها --- */
      case 'toggle-more-menu':
        updateUI((ui) => ({ ...ui, isMoreMenuOpen: !ui.isMoreMenuOpen }));
        break;

      case 'toggle-filter-panel':
        updateUI((ui) => ({
          ...ui,
          isFilterPanelOpen: !ui.isFilterPanelOpen,
        }));
        break;

      case 'close-filter-panel':
        updateUI((ui) => ({ ...ui, isFilterPanelOpen: false }));
        break;

      case 'toggle-analytics':
        updateUI((ui) => ({ ...ui, isAnalyticsOpen: !ui.isAnalyticsOpen }));
        break;

      case 'toggle-template-panel':
        updateUI((ui) => ({
          ...ui,
          isTemplatePanelOpen: !ui.isTemplatePanelOpen,
        }));
        break;

      case 'toggle-header-customize':
        updateUI((ui) => ({
          ...ui,
          isHeaderCustomizeOpen: !ui.isHeaderCustomizeOpen,
        }));
        break;

      /* --- هدر --- */
      case 'header-action':
        handleHeaderAction(actionEl.dataset.headerActionId);
        break;

      case 'header-pin-toggle':
        toggleHeaderPin(actionEl.dataset.headerActionId);
        break;

      /* --- مودال نوت --- */
      case 'open-quick-add':
        openCreateModal();
        break;

      case 'close-modal':
        closeQuickModal();
        break;

      case 'save-quick-note':
        void saveDraftNote();
        break;

      /* --- CRUD نوت --- */
      case 'edit-note':
        openEditModal(noteId);
        break;

      case 'delete-note':
        void trashNote(noteId);
        break;

      case 'restore-note':
        void restoreNote(noteId);
        break;

      case 'duplicate-note':
        void duplicateNote(noteId);
        break;

      case 'toggle-pin':
        togglePin(noteId);
        break;

      case 'toggle-favorite-note':
        toggleFavorite(noteId);
        break;

      case 'toggle-select-note':
        toggleNoteSelection(noteId);
        break;

      case 'toggle-check-item':
        void toggleChecklistItem(noteId, actionEl.dataset.checkId);
        break;

      /* --- چک‌لیست پیش‌نویس --- */
      case 'draft-check-add':
        addDraftCheckItem();
        break;

      case 'draft-check-toggle':
        toggleDraftCheckItem(actionEl.dataset.checkId);
        break;

      case 'draft-check-remove':
        removeDraftCheckItem(actionEl.dataset.checkId);
        break;

      /* --- فیلتر سایدبار --- */
      case 'set-color-filter':
        updateUI((ui) => ({
          ...ui,
          activeColorFilter:
            ui.activeColorFilter === actionEl.dataset.color
              ? 'all'
              : actionEl.dataset.color,
        }));
        break;

      case 'set-priority-filter':
        updateUI((ui) => ({
          ...ui,
          activePriorityFilter:
            ui.activePriorityFilter === actionEl.dataset.priority
              ? 'all'
              : actionEl.dataset.priority,
        }));
        break;

      case 'show-all':
        updateUI((ui) => ({
          ...ui,
          activeBucket: 'all',
          showFavoritesOnly: false,
          showPinnedOnly: false,
          showArchivedOnly: false,
          showTrashOnly: false,
          showChecklistOnly: false,
          showOverdueOnly: false,
          showTodayOnly: false,
        }));
        break;

      case 'toggle-favorites':
        updateUI((ui) => ({
          ...ui,
          activeBucket: 'favorites',
          showFavoritesOnly: !ui.showFavoritesOnly,
          showTrashOnly: false,
        }));
        break;

      case 'toggle-pinned-filter':
        updateUI((ui) => ({
          ...ui,
          activeBucket: 'pinned',
          showPinnedOnly: !ui.showPinnedOnly,
          showTrashOnly: false,
        }));
        break;

      case 'toggle-archive':
        updateUI((ui) => ({
          ...ui,
          activeBucket: 'archive',
          showArchivedOnly: !ui.showArchivedOnly,
          showTrashOnly: false,
        }));
        break;

      case 'toggle-trash':
        updateUI((ui) => ({
          ...ui,
          activeBucket: 'trash',
          showTrashOnly: !ui.showTrashOnly,
          showArchivedOnly: false,
        }));
        break;

      case 'toggle-checklist-filter':
        updateUI((ui) => ({
          ...ui,
          showChecklistOnly: !ui.showChecklistOnly,
        }));
        break;

      case 'filter-overdue':
        updateUI((ui) => ({
          ...ui,
          showOverdueOnly: !ui.showOverdueOnly,
          showTodayOnly: false,
        }));
        break;

      case 'filter-today':
        updateUI((ui) => ({
          ...ui,
          showTodayOnly: !ui.showTodayOnly,
          showOverdueOnly: false,
        }));
        break;

      case 'clear-filters':
        resetFilters();
        break;

      case 'empty-trash':
        void emptyTrash();
        break;

      /* --- نماها --- */
      case 'set-view':
        updateUI((ui) => ({
          ...ui,
          activeView: actionEl.dataset.view || 'grid',
        }));
        break;

      case 'toggle-selection-mode':
        updateUI((ui) => ({
          ...ui,
          selectionMode: !ui.selectionMode,
          selectedIds: ui.selectionMode ? [] : ui.selectedIds,
          isBulkBarOpen: ui.selectionMode ? false : ui.isBulkBarOpen,
        }));
        break;

      /* --- عملیات گروهی --- */
      case 'bulk-pin':
        void bulkUpdateSelected((note) => ({ pinned: !note.pinned }));
        break;

      case 'bulk-favorite':
        void bulkUpdateSelected(() => ({ favorite: true }));
        break;

      case 'bulk-archive':
        void bulkUpdateSelected(() => ({ archived: true, trashed: false }));
        break;

      case 'bulk-trash':
        void bulkUpdateSelected(() => ({ trashed: true, archived: false }));
        break;

      case 'bulk-restore':
        void bulkUpdateSelected(() => ({ trashed: false }));
        break;

      case 'bulk-delete-permanent':
        void (async () => {
          const count = state.ui.selectedIds.length;
          const accepted = await askConfirm({
            title: 'حذف دائمی گروهی',
            message: `${faNumber(count)} یادداشت برای همیشه حذف می‌شوند.`,
            confirmLabel: 'حذف دائمی',
            danger: true,
          });
          if (!accepted) return;

          const ids = [...state.ui.selectedIds];
          try {
            await enqueueOp(async () => {
              for (const id of ids) {
                await deleteToolItem(TOOL_NAME, id);
              }
            });
            if (isCtxAborted()) return;
            setState(
              {
                notes: state.notes.filter(
                  (n) => !ids.map(String).includes(String(n.id))
                ),
                ui: {
                  ...state.ui,
                  selectedIds: [],
                  isBulkBarOpen: false,
                  selectionMode: false,
                },
              },
              { preserveFocus: false }
            );
            showToast('یادداشت‌ها برای همیشه حذف شدند.', 'info');
          } catch (err) {
            console.error('[NotePage] bulk delete failed:', err);
            showToast('حذف گروهی کامل نشد.', 'error');
          }
        })();
        break;

      case 'bulk-select-all':
        selectAllVisible();
        break;

      case 'bulk-clear':
        updateUI((ui) => ({
          ...ui,
          selectedIds: [],
          isBulkBarOpen: false,
          selectionMode: false,
        }));
        break;

      /* --- قالب‌ها --- */
      case 'create-template-daily':
        createNoteFromTemplate('daily');
        break;

      case 'create-template-project':
        createNoteFromTemplate('project');
        break;

      case 'create-template-brainstorm':
        createNoteFromTemplate('brainstorm');
        break;

      case 'create-template-meeting':
        createNoteFromTemplate('meeting');
        break;

      /* --- تم / تراکم (سازگاری با اکشن‌های قدیمی) --- */
      case 'toggle-theme':
        handleHeaderAction('toggle-theme');
        break;

      case 'toggle-density':
        handleHeaderAction('toggle-density');
        break;

      /* --- تأیید / Toast --- */
      case 'confirm-accept':
        settleConfirm(true);
        break;

      case 'confirm-cancel':
        settleConfirm(false);
        break;

      case 'toast-dismiss':
        dismissToast(Number(actionEl.dataset.toastId));
        break;

      case 'toast-action': {
        const toast = toasts.find(
          (t) => t.id === Number(actionEl.dataset.toastId)
        );
        dismissToast(Number(actionEl.dataset.toastId));
        try {
          toast?.action?.run?.();
        } catch (err) {
          console.error('[NotePage] toast action failed:', err);
        }
        break;
      }

      /* --- خطا / تلاش مجدد --- */
      case 'retry-load':
        void loadNotes();
        break;

      default:
        break;
    }
  }

  function handleChange(e) {
    const target = e.target;

    if (target.matches('[data-change="search-scope"]')) {
      updateUI((ui) => ({ ...ui, searchScope: target.value }));
      return;
    }
    if (target.matches('[data-change="sort"]')) {
      updateUI((ui) => ({ ...ui, activeSort: target.value }));
      return;
    }
    if (target.matches('[data-change="group-by"]')) {
      updateUI((ui) => ({ ...ui, groupBy: target.value }));
      return;
    }

    const draftFieldMap = {
      'quick-note-priority': 'priority',
      'quick-note-color': 'color',
      'quick-note-status': 'status',
    };

    const changeType = target.dataset?.change;
    const field = draftFieldMap[changeType];
    if (field) {
      updateUI(
        (ui) => ({
          ...ui,
          draftNote: { ...ui.draftNote, [field]: target.value },
        }),
        { preserveFocus: false }
      );
    }
  }

  function handleInput(e) {
    const target = e.target;
    const inputType = target.dataset?.input;

    if (inputType === 'search-query') {
      state.ui.query = target.value; // بدون رندر فوری
      persistPrefs();
      scheduleSearchRender();
      return;
    }

    const fieldMap = {
      'quick-note-title': 'title',
      'quick-note-content': 'content',
      'quick-note-category': 'category',
      'quick-note-dueAt': 'dueAt',
      'quick-note-tags': 'tags',
    };

    const field = fieldMap[inputType];
    if (!field) return;

    // فقط state — بدون رندر مجدد تا فوکوس حفظ شود
    state.ui.draftNote = { ...state.ui.draftNote, [field]: target.value };
    state.meta.updatedAt = new Date().toISOString();
    persistPrefs();
  }

  function handleKeyDown(e) {
    const target = e.target;
    const isTyping =
      target instanceof HTMLElement &&
      (target.tagName === 'INPUT' ||
        target.tagName === 'TEXTAREA' ||
        target.tagName === 'SELECT' ||
        target.isContentEditable);

    // Enter روی ورودی چک‌لیست
    if (
      e.key === 'Enter' &&
      target?.dataset?.input === 'quick-check-new'
    ) {
      e.preventDefault();
      addDraftCheckItem();
      return;
    }

    // Ctrl/Cmd + Enter => ذخیره هنگام باز بودن مودال
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && state.ui.isQuickAddOpen) {
      e.preventDefault();
      void saveDraftNote();
      return;
    }

    if (e.key === 'Escape') {
      if (confirmState) {
        settleConfirm(false);
        return;
      }
      updateUI((ui) => ({
        ...ui,
        isMoreMenuOpen: false,
        isQuickAddOpen: false,
        editingNoteId: null,
        isTemplatePanelOpen: false,
        isHeaderCustomizeOpen: false,
        isFilterPanelOpen: false,
      }));
      return;
    }

    // میانبر "/" برای فوکوس جستجو (خارج از حالت تایپ)
    if (e.key === '/' && !isTyping) {
      const search = root?.querySelector('[data-input="search-query"]');
      if (search) {
        e.preventDefault();
        search.focus();
      }
    }
  }

  function scheduleSearchRender() {
    window.clearTimeout(searchDebounceTimer);
    searchDebounceTimer = window.setTimeout(() => {
      if (isDestroyed) return;
      rerender({ preserveFocus: true });
    }, SEARCH_DEBOUNCE_MS);
  }

  /* ---------- پیش‌نویس چک‌لیست ---------- */

  function addDraftCheckItem() {
    const input = root?.querySelector('[data-input="quick-check-new"]');
    const text = String(input?.value || '').trim();
    if (!text) return;

    updateUI(
      (ui) => ({
        ...ui,
        draftNote: {
          ...ui.draftNote,
          checklist: [
            ...ui.draftNote.checklist,
            { id: createLocalId('check'), text, done: false },
          ],
        },
      }),
      { preserveFocus: false }
    );

    // بازگرداندن فوکوس به ورودی برای افزودن سریع مورد بعدی
    window.requestAnimationFrame(() => {
      root?.querySelector('[data-input="quick-check-new"]')?.focus();
    });
  }

  function toggleDraftCheckItem(checkId) {
    updateUI(
      (ui) => ({
        ...ui,
        draftNote: {
          ...ui.draftNote,
          checklist: ui.draftNote.checklist.map((item) =>
            String(item.id) === String(checkId)
              ? { ...item, done: !item.done }
              : item
          ),
        },
      }),
      { preserveFocus: false }
    );
  }

  function removeDraftCheckItem(checkId) {
    updateUI(
      (ui) => ({
        ...ui,
        draftNote: {
          ...ui.draftNote,
          checklist: ui.draftNote.checklist.filter(
            (item) => String(item.id) !== String(checkId)
          ),
        },
      }),
      { preserveFocus: false }
    );
  }

  /* ---------- مودال ---------- */

  function openCreateModal() {
    updateUI((ui) => ({
      ...ui,
      isQuickAddOpen: true,
      editingNoteId: null,
      draftNote: createEmptyDraft(),
      isMoreMenuOpen: false,
    }));
  }

  function openEditModal(noteId) {
    const note = findNoteById(noteId);
    if (!note) return;

    updateUI((ui) => ({
      ...ui,
      isQuickAddOpen: true,
      editingNoteId: String(noteId),
      draftNote: {
        title: note.title || '',
        content: note.content || '',
        category: note.category || '',
        priority: note.priority || 'medium',
        color: note.color || 'blue',
        status: note.status || 'todo',
        dueAt: note.dueAt || '',
        tags: Array.isArray(note.tags) ? note.tags.join(', ') : '',
        checklist: structuredClone(
          Array.isArray(note.checklist) ? note.checklist : []
        ),
      },
      isMoreMenuOpen: false,
    }));
  }

  function closeQuickModal() {
    updateUI((ui) => ({
      ...ui,
      isQuickAddOpen: false,
      editingNoteId: null,
      draftNote: createEmptyDraft(),
    }));
  }

  /* =========================================================
   * Drag & Drop (نمای برد)
   * ========================================================= */

  function handleDragStart(e) {
    const card = e.target.closest?.('.note-card[draggable="true"]');
    if (!card || state.ui.activeView !== 'board') return;

    const noteId = card.dataset.noteId;
    e.dataTransfer.setData('text/plain', noteId);
    e.dataTransfer.effectAllowed = 'move';
    card.classList.add('is-dragging');
  }

  function handleDragOver(e) {
    const body = e.target.closest?.('.note-board-body');
    if (!body) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    body.closest('.note-board-column')?.classList.add('is-drop-target');
  }

  function handleDragLeave(e) {
    const column = e.target.closest?.('.note-board-column');
    if (!column) return;
    if (column.contains(e.relatedTarget)) return;
    column.classList.remove('is-drop-target');
  }

  function handleDrop(e) {
    const body = e.target.closest?.('.note-board-body');
    if (!body) return;
    e.preventDefault();

    const noteId = e.dataTransfer.getData('text/plain');
    const status = body.dataset.status;

    body
      .closest('.note-board-column')
      ?.classList.remove('is-drop-target');

    if (!noteId || !status) return;

    const note = findNoteById(noteId);
    if (!note || note.status === status) return;

    void commitUpdate(noteId, { status }).then((ok) => {
      if (ok) showToast(`به «${STATUS_LABELS[status]}» منتقل شد.`, 'success');
    });
  }

  function handleDragEnd() {
    root
      ?.querySelectorAll('.is-dragging, .is-drop-target')
      .forEach((el) => el.classList.remove('is-dragging', 'is-drop-target'));
  }

  /* =========================================================
   * چرخه حیات
   * ========================================================= */

  function attachRoot() {
    root = document.getElementById(PAGE_ID);
    if (!root) return;

    root.addEventListener('click', handleClick);
    root.addEventListener('change', handleChange);
    root.addEventListener('input', handleInput);
    root.addEventListener('keydown', handleKeyDown);
    root.addEventListener('dragstart', handleDragStart);
    root.addEventListener('dragover', handleDragOver);
    root.addEventListener('dragleave', handleDragLeave);
    root.addEventListener('drop', handleDrop);
    root.addEventListener('dragend', handleDragEnd);

    syncToastLayer();
  }

  function setupStoreSubscription() {
    if (unsubscribeStore) return;
    try {
      unsubscribeStore = appStore.subscribe(
        ({ previousState, currentState }) => {
          if (isDestroyed) return;
          const prevTheme = selectTheme(previousState) || 'light';
          const nextTheme = selectTheme(currentState) || 'light';
          if (prevTheme !== nextTheme && nextTheme !== state.ui.theme) {
            setState({ ui: { ...state.ui, theme: nextTheme } }, { persist: true });
          }
        }
      );
    } catch (err) {
      console.warn('[NotePage] store subscribe failed:', err);
    }
  }

  function afterRender() {
    attachRoot();
    setupStoreSubscription();

    if (!hasLoaded) {
      void loadNotes();
    }
  }

  function destroy() {
    isDestroyed = true;

    window.clearTimeout(searchDebounceTimer);

    for (const timer of toastTimers.values()) {
      window.clearTimeout(timer);
    }
    toastTimers.clear();
    toasts = [];

    if (confirmResolver) {
      settleConfirm(false);
    }

    if (unsubscribeStore) {
      try {
        unsubscribeStore();
      } catch {
        /* ignore */
      }
      unsubscribeStore = null;
    }

    if (root) {
      root.removeEventListener('click', handleClick);
      root.removeEventListener('change', handleChange);
      root.removeEventListener('input', handleInput);
      root.removeEventListener('keydown', handleKeyDown);
      root.removeEventListener('dragstart', handleDragStart);
      root.removeEventListener('dragover', handleDragOver);
      root.removeEventListener('dragleave', handleDragLeave);
      root.removeEventListener('drop', handleDrop);
      root.removeEventListener('dragend', handleDragEnd);
      root = null;
    }
  }

  /* =========================================================
   * ابزارهای کمکی
   * ========================================================= */

  function icon(name, size = 16) {
    const body = ICON_PATHS[name] || ICON_PATHS.note;
    return `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${body}</svg>`;
  }

  function renderOptions(options, activeValue) {
    return options
      .map(
        ([value, label]) =>
          `<option value="${escapeHtml(value)}" ${
            value === activeValue ? 'selected' : ''
          }>${escapeHtml(label)}</option>`
      )
      .join('');
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function faNumber(value) {
    try {
      return new Intl.NumberFormat('fa-IR').format(value ?? 0);
    } catch {
      return String(value ?? 0);
    }
  }

  const dateLongFmt = new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const dateShortFmt = new Intl.DateTimeFormat('fa-IR', {
    month: 'short',
    day: 'numeric',
  });

  function formatDateLong(input) {
    const date = new Date(input);
    if (Number.isNaN(date.getTime())) return '';
    try {
      return dateLongFmt.format(date);
    } catch {
      return '';
    }
  }

  function formatDateShort(input) {
    const date = new Date(input);
    if (Number.isNaN(date.getTime())) return '—';
    try {
      return dateShortFmt.format(date);
    } catch {
      return '—';
    }
  }

  const relativeFmt = new Intl.RelativeTimeFormat('fa-IR', {
    numeric: 'auto',
  });

  function relativeTime(input) {
    const time = new Date(input).getTime();
    if (Number.isNaN(time)) return '';

    const diff = time - Date.now();
    const abs = Math.abs(diff);

    const minutes = Math.round(abs / 60000);
    if (minutes < 1) return 'همین حالا';
    if (minutes < 60)
      return relativeFmt.format(Math.sign(diff) * minutes, 'minute');

    const hours = Math.round(minutes / 60);
    if (hours < 24)
      return relativeFmt.format(Math.sign(diff) * hours, 'hour');

    const days = Math.round(hours / 24);
    if (days < 30)
      return relativeFmt.format(Math.sign(diff) * days, 'day');

    return formatDateShort(input);
  }

  function getPreview(text) {
    const s = String(text || '').replace(/\s+/g, ' ').trim();
    if (!s) return 'بدون محتوا';
    return s.length > 160 ? `${s.slice(0, 160)}…` : s;
  }

  /* ---------- API عمومی برای روتر ---------- */

  return {
    render,
    afterRender,
    destroy,
  };
}

export default createNotePage;
